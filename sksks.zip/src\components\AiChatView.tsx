import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Trash2,
  Maximize2,
  Copy,
  Check,
  FilePlus,
  CheckSquare,
  Bot,
  LayoutDashboard,
  ChevronDown,
  X,
  FileText,
  Lock,
  LogIn,
  Zap,
  History,
  Plus,
  AtSign,
  ArrowUp,
  ExternalLink,
  MessageSquare,
  Clock,
  Compass,
} from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { useAuth } from '../context/AuthContext';
import { reasonAboutUserInput, ReasoningResult } from '../features/ai/reasoning';
import { composeBotAnswer } from '../features/ai/answering';
import { conversationMemory } from '../features/ai/conversationMemory';
import { puterAi } from '../features/ai/puterService';
import {
  performMultiSourceResearch,
  ResearchOptions,
  NoteStyleOption,
  NoteFocusOption,
} from '../features/ai/multiSourceResearchService';
import { subscriptionService } from '../services/subscriptionService';
import { PlansModal } from './PlansModal';
import { copyFullNoteToClipboard } from '../utils/noteExportCopy';
import { knowledgeIndex } from '../features/ai/knowledgeIndexService';
import { parseMarkdownToNotionBlocks } from '../features/ai/markdownToBlocks';
import {
  findPageByTitleQuery,
  summarizePage,
  extractActionItemsFromPage,
  createMeetingNotesBlocks,
  auditPageQuality,
} from '../features/ai/noteOpsService';
import { AI_COMMANDS, matchAiCommands, AiCommandDef } from '../features/ai/commandsRegistry';
import { DocBlock, TaskStatus, WorkspacePage } from '../types/workspace';

interface ResearchProgressState {
  step: number;
  totalSteps: number;
  stageName: string;
  percent: number;
  secondsLeft: number;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: number;
  actionType?: string;
  suggestedPills?: string[];
  pageId?: string;
  pageTitle?: string;
  modelUsed?: string;
  modeChoice?: { topic: string };
  isResearching?: boolean;
  researchProgress?: ResearchProgressState;
  generatedBlocks?: DocBlock[];
}

interface AiChatViewProps {
  isCompact?: boolean;
  onSwitchWorkspace?: () => void;
  onExpandFullscreen?: () => void;
  onClose?: () => void;
}

export const AiChatView: React.FC<AiChatViewProps> = ({
  isCompact = false,
  onSwitchWorkspace,
  onExpandFullscreen,
  onClose,
}) => {
  const { user, setIsAuthModalOpen, quickLocalLogin } = useAuth();
  const {
    pages,
    tasks,
    activeDoc,
    createPage,
    addTask,
    updateTaskStatus,
    insertBlocks,
    setActivePageId,
    setActiveView,
    addNotification,
    smartMergePageWithResearch,
  } = useWorkspace();

  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [copiedDocId, setCopiedDocId] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState<'Auto' | 'Claude 3.5' | 'GPT-4o'>('Auto');
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [isPlansModalOpen, setIsPlansModalOpen] = useState(false);

  // Opcje personalizacji dokumentu przed wygenerowaniem
  const [customStyle, setCustomStyle] = useState<NoteStyleOption>('comprehensive');
  const [customFocus, setCustomFocus] = useState<NoteFocusOption>('highlights');
  const [includeQuestions, setIncludeQuestions] = useState<boolean>(false);

  // Command palette autocomplete state
  const [matchedCommands, setMatchedCommands] = useState<AiCommandDef[]>([]);
  const [selectedCommandIndex, setSelectedCommandIndex] = useState(0);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Load chat history from localStorage
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('searchpoint_notion_ai_messages');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('searchpoint_notion_ai_messages', JSON.stringify(messages));
    } catch {}
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleClearHistory = () => {
    if (window.confirm('Czy na pewno chcesz wyczyścić historię rozmowy z Asystentem AI?')) {
      setMessages([]);
      localStorage.removeItem('searchpoint_notion_ai_messages');
      conversationMemory.clearHistory();
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 1500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setInput(val);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }

    if (val.startsWith('/')) {
      const q = val.slice(1).toLowerCase();
      const hits = matchAiCommands(q);
      setMatchedCommands(hits);
      setIsCommandPaletteOpen(hits.length > 0);
      setSelectedCommandIndex(0);
    } else {
      setIsCommandPaletteOpen(false);
    }
  };

  const handleTextareaKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (isCommandPaletteOpen && matchedCommands.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedCommandIndex((prev) => (prev + 1) % matchedCommands.length);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedCommandIndex((prev) => (prev - 1 + matchedCommands.length) % matchedCommands.length);
        return;
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        const selected = matchedCommands[selectedCommandIndex];
        setInput(`${selected.command} `);
        setIsCommandPaletteOpen(false);
        return;
      }
      if (e.key === 'Escape') {
        setIsCommandPaletteOpen(false);
        return;
      }
    }

    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  /**
   * Wykonanie tworzenia notatki w wybranym trybie (Szybkość vs Precyzja 25s) z uwzględnieniem stylów i bramki Free/Pro
   */
  const handleExecuteNoteCreation = async (
    topic: string,
    mode: 'quick_note' | 'deep_research',
    overrideOptions?: ResearchOptions
  ) => {
    // 1. Sprawdzenie limitu planu Free (KROK 10, 11, 12)
    const gateCheck = subscriptionService.canCreateAiNote();
    if (!gateCheck.allowed) {
      const limitMsg: ChatMessage = {
        id: `msg-limit-${Date.now()}`,
        sender: 'assistant',
        content: `🔒 **Osiągnięto limit planu Free (3 notatki / dzień)**\n\n${gateCheck.reason}\n\nMożesz nadal swobodnie rozmawiać z AI i zadawać pytania, a nielimitowane generowanie notatek AI odblokujesz w planie Pro.`,
        timestamp: Date.now(),
        actionType: 'plan_limit_reached',
        suggestedPills: ['Pokaż ofertę Pro (8 zł/mc)', 'Zadaj pytanie bez tworzenia strony'],
      };
      setMessages((prev) => [...prev, limitMsg]);
      setIsPlansModalOpen(true);
      return;
    }

    const options: ResearchOptions = {
      depth: mode,
      style: overrideOptions?.style || customStyle,
      focus: overrideOptions?.focus || customFocus,
      includeQuestions: overrideOptions?.includeQuestions ?? includeQuestions,
    };

    if (mode === 'quick_note') {
      setIsTyping(true);
      try {
        const res = await performMultiSourceResearch(topic, options);
        subscriptionService.recordAiNoteCreation();

        const newPageId = await createPage(undefined, res.resolvedTitle, res.blocks, 'Document', '⚡');

        if (newPageId) {
          setActivePageId(newPageId);
          setActiveView('doc');
        }

        const botMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          sender: 'assistant',
          content: `⚡ **Utworzono stronę w trybie Szybkości (Instant 1s): "${res.resolvedTitle}"**\n\n` +
            `Wygenerowano ${res.blocks.length} bloków z dynamiczną architekturą, wprowadzeniem, tabelą oraz bibliografią z ${res.uniqueDomainsCount} niezależnych domen.\n\n` +
            `Strona została zapisana i otwarta w edytorze.`,
          timestamp: Date.now(),
          actionType: 'create_note',
          pageId: newPageId,
          pageTitle: res.resolvedTitle,
          generatedBlocks: res.blocks,
          suggestedPills: [
            `Streszcz ${res.resolvedTitle}`,
            `Wyciągnij zadania`,
            `Zbadaj ${res.resolvedTitle} w 4 źródłach`,
          ],
        };

        setMessages((prev) => [...prev, botMsg]);
        addNotification('Utworzono stronę', `Notatka "${res.resolvedTitle}" jest gotowa.`, 'success', newPageId);
      } catch (err) {
        console.error('Błąd tworzenia notatki:', err);
      } finally {
        setIsTyping(false);
      }
      return;
    }

    // Tryb Precyzja (Deep 25s · 4+ niezależne źródła)
    const progressMsgId = `progress-${Date.now()}`;
    const initialProgress: ResearchProgressState = {
      step: 1,
      totalSteps: 4,
      stageName: 'Przeszukiwanie rejestrów naukowych (OpenAlex & Crossref)...',
      percent: 15,
      secondsLeft: 25,
    };

    const progressMsg: ChatMessage = {
      id: progressMsgId,
      sender: 'assistant',
      content: `🔬 **Uruchomiono tryb Precyzji dla: "${topic}"**\n` +
        `Rozpoczynam rygorystyczną weryfikację krzyżową w 4 niezależnych domenach (OpenAlex, Wikidata, Crossref, Web).`,
      timestamp: Date.now(),
      isResearching: true,
      researchProgress: initialProgress,
    };

    setMessages((prev) => [...prev, progressMsg]);
    setIsTyping(false);

    let secondsRemaining = 25;
    const researchPromise = performMultiSourceResearch(topic, options);

    const intervalId = setInterval(() => {
      secondsRemaining -= 1;

      let step = 1;
      let stageName = 'Przeszukiwanie rejestrów naukowych (OpenAlex & Crossref)...';
      let percent = 20;

      if (secondsRemaining <= 18 && secondsRemaining > 12) {
        step = 2;
        stageName = 'Weryfikacja semantyczna w grafie wiedzy Wikidata...';
        percent = 45;
      } else if (secondsRemaining <= 12 && secondsRemaining > 5) {
        step = 3;
        stageName = 'Badanie konsensusu i eliminacja sprzeczności w 4 domenach...';
        percent = 75;
      } else if (secondsRemaining <= 5 && secondsRemaining > 0) {
        step = 4;
        stageName = 'Dynamiczne generowanie unikalnej architektury bloków...';
        percent = 92;
      } else if (secondsRemaining <= 0) {
        percent = 100;
        stageName = 'Finalizacja strony i zapis do bazy danych...';
      }

      setMessages((prev) =>
        prev.map((m) =>
          m.id === progressMsgId
            ? {
                ...m,
                researchProgress: {
                  step,
                  totalSteps: 4,
                  stageName,
                  percent,
                  secondsLeft: Math.max(0, secondsRemaining),
                },
              }
            : m
        )
      );

      if (secondsRemaining <= 0) {
        clearInterval(intervalId);
      }
    }, 1000);

    try {
      const res = await researchPromise;
      // Poczekaj na ukończenie pełnego 25-sekundowego cyklu badania precyzyjnego
      if (secondsRemaining > 0) {
        await new Promise((resolve) => setTimeout(resolve, secondsRemaining * 1000));
      }
      clearInterval(intervalId);

      const newPageId = await createPage(undefined, res.resolvedTitle, res.blocks, 'Document', '🔬');
      subscriptionService.recordAiNoteCreation();

      if (newPageId) {
        setActivePageId(newPageId);
        setActiveView('doc');
      }

      const domainList = res.sources.map((s) => `• **${s.domain}** (${s.authorOrPublisher || 'Oficjalny rejestr'})`).slice(0, 4).join('\n');

      setMessages((prev) =>
        prev.map((m) =>
          m.id === progressMsgId
            ? {
                ...m,
                isResearching: false,
                content: `🔬 **Zakończono wieloźródłowe badanie AI (25s): "${res.resolvedTitle}"**\n\n` +
                  `Zweryfikowano fakty w oparciu o **${res.uniqueDomainsCount} niezależne domeny** bez wykrycia sprzeczności:\n` +
                  `${domainList}\n\n` +
                  `💡 **Kluczowy konsensus:**\n${res.keyTakeaway}\n\n` +
                  `Notatka z ${res.blocks.length} unikalnymi blokami (bez sztywnego szablonu) została utworzona i otwarta w edytorze.`,
                pageId: newPageId,
                pageTitle: res.resolvedTitle,
                generatedBlocks: res.blocks,
                suggestedPills: [
                  `Streszcz ${res.resolvedTitle}`,
                  `Wyciągnij zadania`,
                  `Dodaj podstronę do ${res.resolvedTitle}`,
                ],
              }
            : m
        )
      );

      addNotification('Zakończono badanie precyzyjne', `Notatka "${res.resolvedTitle}" została zweryfikowana w 4 domenach.`, 'success', newPageId);
    } catch (err) {
      clearInterval(intervalId);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === progressMsgId
            ? {
                ...m,
                isResearching: false,
                content: `Wystąpił problem podczas badania. Wygenerowałem bezpieczną notatkę roboczą w Twoim Workspace.`,
              }
            : m
        )
      );
    }
  };

  /**
   * Wstawienie wygenerowanych bloków do aktualnie otwartej strony w edytorze
   */
  const handleInsertBlocksIntoCurrentDoc = async (blocks?: DocBlock[]) => {
    if (!activeDoc || !blocks || blocks.length === 0) return;
    try {
      await insertBlocks(activeDoc.id, blocks);
      setActiveView('doc');
      addNotification('Wstawiono bloki', `Dodano ${blocks.length} bloków do strony "${activeDoc.title}".`, 'success', activeDoc.id);
    } catch (err) {
      console.error('Błąd wstawiania bloków:', err);
    }
  };

  /**
   * Utworzenie nowej strony z wygenerowanych bloków
   */
  const handleCreatePageFromBlocks = async (title: string, blocks?: DocBlock[]) => {
    if (!blocks || blocks.length === 0) return;
    try {
      const pageId = await createPage(undefined, title || 'Nowa strona', blocks, 'Document', '📄');
      if (pageId) {
        setActivePageId(pageId);
        setActiveView('doc');
        addNotification('Utworzono stronę', `Strona "${title}" została utworzona w edytorze.`, 'success', pageId);
      }
    } catch (err) {
      console.error('Błąd tworzenia strony:', err);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const rawText = (textToSend || input).trim();
    if (!rawText) return;

    setIsCommandPaletteOpen(false);

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      content: rawText,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    setTimeout(async () => {
      await processBotResponse(rawText);
    }, 200);
  };

  const processBotResponse = async (userPrompt: string) => {
    const reasoning = reasonAboutUserInput(userPrompt);

    const activeTasksCount = tasks.filter((t) => t.status !== 'Zrobione').length;
    const doneTasksCount = tasks.filter((t) => t.status === 'Zrobione').length;

    // =========================================================================
    // 1. CAPABILITY SHOWCASE (Odpowiedź na "umiesz w 4 źródłach", "jakie masz źródła")
    // =========================================================================
    if (reasoning.intent === 'CAPABILITY_SHOWCASE') {
      const answer = composeBotAnswer(reasoning, {
        userName: user?.displayName || user?.email?.split('@')[0] || 'Użytkowniku',
        pagesCount: pages.length,
        tasksCount: tasks.length,
        activeTasksCount,
        doneTasksCount,
        pages,
        tasks,
      });

      const botMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        sender: 'assistant',
        content: answer.text,
        timestamp: Date.now(),
        actionType: 'capability_showcase',
        suggestedPills: answer.suggestedPills,
      };

      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
      return;
    }

    // =========================================================================
    // 2. TWORZENIE NOTATKI & DEEP RESEARCH (Z Pytaniem o Tryb Szybkość vs Precyzja)
    // =========================================================================
    if (
      reasoning.actionTrigger === 'create_note_live' ||
      reasoning.intent === 'CREATE_NOTE_LIVE' ||
      reasoning.actionTrigger === 'deep_research' ||
      reasoning.intent === 'DEEP_RESEARCH' ||
      reasoning.actionTrigger === 'note_web' ||
      reasoning.intent === 'NOTE_WEB'
    ) {
      const topic =
        reasoning.extractedTopic ||
        userPrompt
          .replace(/^(@note[_:\s]*|@deepresearch[_:\s]*|@research[_:\s]*|@analyze[_:\s]*|@noteweb[_:\s]*)/i, '')
          .replace(/_/g, ' ')
          .trim() ||
        'Koty';

      const isExplicitQuick = userPrompt.includes('[szybko]') || userPrompt.toLowerCase().includes('szybko');
      const isExplicitDeep = userPrompt.includes('[precyzja]') || userPrompt.toLowerCase().includes('precyzja') || userPrompt.toLowerCase().includes('precyzyjn');

      // Jeśli użytkownik explicite wskazał tryb w prompcie
      if (isExplicitQuick) {
        await handleExecuteNoteCreation(topic, 'quick_note');
        return;
      }
      if (isExplicitDeep) {
        await handleExecuteNoteCreation(topic, 'deep_research');
        return;
      }

      // Prezentacja wyboru: Szybkość (1s) vs Precyzja (25s) zgodnie ze specyfikacją
      const choiceMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        sender: 'assistant',
        content: `Chcesz przygotować kompletną stronę o: **"${topic}"**.\n\nWybierz tryb generowania:`,
        timestamp: Date.now(),
        actionType: 'mode_select',
        modeChoice: { topic },
        suggestedPills: [
          `Szybko: ${topic}`,
          `Precyzja (25s): ${topic}`,
          'Streszcz bieżącą notatkę',
        ],
      };

      setMessages((prev) => [...prev, choiceMsg]);
      setIsTyping(false);
      return;
    }

    // =========================================================================
    // 3. SUMMARIZE NOTE: @streszcz, "streszcz mi notatkę..."
    // =========================================================================
    if (reasoning.actionTrigger === 'summarize_note' || reasoning.intent === 'SUMMARIZE_NOTE') {
      const targetQuery = reasoning.extractedTopic || '';
      const matched = findPageByTitleQuery(pages, targetQuery) || activeDoc;

      if (matched) {
        const summary = summarizePage(matched);
        let reply = `📑 **Streszczenie dokumentu: "${matched.title}"**\n\n`;
        reply += `🏆 **Kluczowy wniosek:**\n${summary.executiveSummary}\n\n`;

        if (summary.keyTakeaways.length > 1) {
          reply += `📌 **Najważniejsze punkty:**\n` + summary.keyTakeaways.slice(1, 4).map((t) => `• ${t}`).join('\n') + `\n\n`;
        }

        reply += `📊 **Metadane:** ${summary.stats.blocksCount} bloków · ok. ${summary.stats.wordCount} słów · czas czytania: ${summary.stats.readingTimeMinutes} min.\n\n`;

        if (summary.suggestedTasks.length > 0) {
          reply += `🎯 **Punkty do realizacji:**\n` + summary.suggestedTasks.map((t) => `• ${t}`).join('\n');
        }

        const botMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          sender: 'assistant',
          content: reply,
          timestamp: Date.now(),
          actionType: 'summarize_note',
          pageId: matched.id,
          pageTitle: matched.title,
          suggestedPills: [`@actionitems ${matched.title}`, 'Otwórz stronę w edytorze'],
        };
        setMessages((prev) => [...prev, botMsg]);
      } else {
        const botMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          sender: 'assistant',
          content: `Nie znalazłem notatki o tytule "${targetQuery}". Wskaż tytuł z listy swoich stron w pasku bocznym.`,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, botMsg]);
      }
      setIsTyping(false);
      return;
    }

    // =========================================================================
    // 4. EXTRACT ACTION ITEMS TO KANBAN: @actionitems
    // =========================================================================
    if (reasoning.actionTrigger === 'extract_action_items' || reasoning.intent === 'EXTRACT_ACTION_ITEMS') {
      const targetQuery = reasoning.extractedTopic || '';
      const matched = findPageByTitleQuery(pages, targetQuery) || activeDoc || pages[0];

      if (matched) {
        const items = extractActionItemsFromPage(matched);
        for (const item of items) {
          await addTask({
            title: item.title,
            status: 'Do zrobienia',
            priority: item.priority,
            tag: 'ActionItem',
            dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
          });
        }

        const botMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          sender: 'assistant',
          content: `🎯 **Wyodrębniono ${items.length} zadań z dokumentu "${matched.title}":**\n\n` +
            items.map((it) => `• [${it.priority}] **${it.title}**`).join('\n') +
            `\n\nWszystkie zadania zostały dodane do Twojej tablicy Kanban.`,
          timestamp: Date.now(),
          suggestedPills: ['Pokaż zadania', 'Wróć do edytora'],
        };
        setMessages((prev) => [...prev, botMsg]);
      }
      setIsTyping(false);
      return;
    }

    // =========================================================================
    // 5. GENERAL QUESTIONS & PUTER AI (Z Automatycznymi Akcjami dla Treści Notatki)
    // =========================================================================
    try {
      let aiText = '';
      if (typeof window !== 'undefined' && (window as any).puter?.ai?.chat) {
        const promptContext = activeDoc
          ? `Kontekst bieżącej otwartej strony: "${activeDoc.title}".\nZapytanie użytkownika: ${userPrompt}`
          : userPrompt;
        const response = await (window as any).puter.ai.chat(promptContext);
        if (response) {
          aiText = typeof response === 'string' ? response : response.message?.content || response.text || '';
        }
      }

      if (!aiText) {
        const answer = composeBotAnswer(reasoning, {
          userName: user?.displayName || user?.email?.split('@')[0] || 'Użytkowniku',
          pagesCount: pages.length,
          tasksCount: tasks.length,
          activeTasksCount,
          doneTasksCount,
          pages,
          tasks,
        });
        aiText = answer.text;
      }

      // Sprawdzenie czy wygenerowany tekst zawiera strukturę notatki (np. nagłówki, listy)
      const hasStructure = aiText.includes('#') || aiText.split('\n').length >= 4;
      const parsed = hasStructure ? parseMarkdownToNotionBlocks(aiText, reasoning.extractedTopic) : null;

      const botMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        sender: 'assistant',
        content: aiText,
        timestamp: Date.now(),
        pageTitle: parsed?.title,
        generatedBlocks: parsed?.blocks,
        suggestedPills: [
          `Stwórz notatkę o ${reasoning.extractedTopic || 'tym temacie'}`,
          `Zbadaj ${reasoning.extractedTopic || 'ten temat'} w 4 źródłach`,
          'Wyciągnij zadania',
        ],
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      const answer = composeBotAnswer(reasoning, {
        userName: user?.displayName || user?.email?.split('@')[0] || 'Użytkowniku',
        pagesCount: pages.length,
        tasksCount: tasks.length,
        activeTasksCount,
        doneTasksCount,
        pages,
        tasks,
      });
      const botMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        sender: 'assistant',
        content: answer.text,
        timestamp: Date.now(),
        suggestedPills: answer.suggestedPills,
      };
      setMessages((prev) => [...prev, botMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  // If user is not logged in: AI requires authentication
  if (!user) {
    return (
      <div className="flex-1 h-full flex flex-col bg-white dark:bg-[#191919] border-l border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] overflow-y-auto font-sans text-[#37352f] dark:text-[#d4d4d4]">
        <div className="px-4 py-2.5 border-b border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] flex items-center justify-between bg-[#fbfbfa] dark:bg-[#1c1c1c] shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-[4px] bg-[#2383e2] text-white flex items-center justify-center font-bold text-xs shadow-2xs">
              <Sparkles size={13} />
            </div>
            <div>
              <div className="font-semibold text-xs text-[#37352f] dark:text-white flex items-center gap-1.5">
                <span>Asystent AI</span>
                <span className="text-[10px] text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 px-1.5 py-0.2 rounded-[3px] flex items-center gap-1">
                  <Lock size={9} />
                  <span>Wymagane logowanie</span>
                </span>
              </div>
            </div>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1 text-[#787774] hover:text-[#37352f] dark:hover:text-white rounded-[4px] cursor-pointer"
            >
              <X size={14} />
            </button>
          )}
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-sm mx-auto">
          <div className="w-12 h-12 rounded-[10px] bg-[#2383e2]/10 text-[#2383e2] flex items-center justify-center mb-3">
            <Sparkles size={24} />
          </div>

          <h2 className="text-base font-bold text-[#37352f] dark:text-white tracking-tight mb-1.5">
            Zaloguj się do Asystenta AI
          </h2>
          <p className="text-xs text-[#787774] dark:text-[#9b9a97] leading-relaxed mb-5">
            Asystent AI analizuje Twoje dokumenty, tworzy notatki z badań wieloźródłowych i wyciąga zadania na tablicę Kanban.
          </p>

          <div className="w-full space-y-2">
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="w-full py-2 px-3 bg-[#2383e2] hover:bg-[#1d6fc2] text-white font-medium text-xs rounded-[4px] cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
            >
              <LogIn size={13} />
              <span>Zaloguj się</span>
            </button>

            <button
              onClick={() => quickLocalLogin('Użytkownik Workspace')}
              className="w-full py-1.5 px-3 bg-white dark:bg-[#202020] hover:bg-[rgba(55,53,47,0.04)] text-[#37352f] dark:text-[#d4d4d4] font-medium text-xs rounded-[4px] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] cursor-pointer transition-colors flex items-center justify-center gap-1.5"
            >
              <Zap size={12} className="text-amber-500" />
              <span>Szybkie logowanie demo</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-white dark:bg-[#191919] text-[#37352f] dark:text-[#d4d4d4] font-sans overflow-hidden select-none">
      {/* ========================================================================= */}
      {/* 1. STUDIO AI HEADER (Top bar identical to Studio AI sidecar)               */}
      {/* ========================================================================= */}
      <div className="h-11 px-3.5 border-b border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] bg-[#fbfbfa] dark:bg-[#1c1c1c] flex items-center justify-between shrink-0 select-none">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-[4px] bg-[#2383e2] text-white flex items-center justify-center shadow-2xs">
            <Sparkles size={11} />
          </div>
          <div>
            <div className="font-semibold text-xs text-[#37352f] dark:text-white flex items-center gap-1.5">
              <span>Asystent AI</span>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-normal">
                4+ Źródła Online
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[#787774] dark:text-[#9b9a97]">
          <button
            onClick={handleClearHistory}
            className="p-1 hover:text-[#eb5757] hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.08)] rounded-[3px] cursor-pointer"
            title="Wyczyść historię"
          >
            <Trash2 size={13} />
          </button>
          {onExpandFullscreen && (
            <button
              onClick={onExpandFullscreen}
              className="p-1 hover:text-[#37352f] dark:hover:text-white hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.08)] rounded-[3px] cursor-pointer"
              title="Maksymalizuj panel"
            >
              <Maximize2 size={13} />
            </button>
          )}
          {onClose && (
            <button
              onClick={onClose}
              className="p-1 hover:text-[#37352f] dark:hover:text-white hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.08)] rounded-[3px] cursor-pointer ml-0.5"
              title="Zamknij panel AI (Ctrl+D)"
            >
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. CONVERSATION MESSAGES STREAM                                            */}
      {/* ========================================================================= */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col justify-center items-center text-center p-6 text-[#787774] dark:text-[#9b9a97] space-y-3">
            <div className="w-10 h-10 rounded-[8px] bg-[#2383e2]/10 text-[#2383e2] flex items-center justify-center">
              <Sparkles size={20} />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#37352f] dark:text-white">
                Witaj w Asystencie AI
              </h3>
              <p className="text-xs text-[#787774] dark:text-[#9b9a97] mt-1 max-w-xs leading-relaxed">
                Wpisz dowolne polecenie w języku naturalnym, np. <em>„Stwórz notatkę o psach”</em> lub poproś o podsumowanie strony.
              </p>
            </div>

            <div className="w-full space-y-1.5 pt-3 max-w-xs text-left">
              {[
                { icon: '🐾', prompt: 'Stwórz notatkę o kotach' },
                { icon: '⚡', prompt: 'Stwórz notatkę o TypeScript' },
                { icon: '🔬', prompt: 'Zbadaj rynek w 4 źródłach' },
                { icon: '🎯', prompt: 'Wyciągnij zadania z bieżącej notatki' },
              ].map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(item.prompt)}
                  className="w-full p-2 bg-[#fbfbfa] dark:bg-[#202020] hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.055)] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] rounded-[6px] text-xs text-[#37352f] dark:text-[#d4d4d4] flex items-center gap-2 cursor-pointer transition-colors text-left"
                >
                  <span className="text-sm">{item.icon}</span>
                  <span className="truncate">{item.prompt}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <div key={msg.id} className="space-y-1.5">
              {msg.sender === 'user' ? (
                <div className="flex justify-end">
                  <div className="bg-[rgba(55,53,47,0.06)] dark:bg-[rgba(255,255,255,0.08)] text-[#37352f] dark:text-white px-3 py-1.5 rounded-[12px] rounded-br-[3px] text-xs max-w-[85%] leading-relaxed select-text">
                    {msg.content}
                  </div>
                </div>
              ) : (
                <div className="space-y-2 group">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-[3px] bg-[#2383e2]/10 text-[#2383e2] flex items-center justify-center shrink-0 mt-0.5">
                      <Sparkles size={11} />
                    </div>
                    <div className="flex-1 min-w-0 text-xs text-[#37352f] dark:text-[#d4d4d4] leading-relaxed whitespace-pre-wrap select-text">
                      {msg.content}
                    </div>
                  </div>

                  {/* WYBÓR TRYBU GENEROWANIA & PERSONALIZACJA PRZED TWORZENIEM NOTATKI (KROK 3) */}
                  {msg.modeChoice && (
                    <div className="ml-7 mt-2 p-3 rounded-[6px] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] bg-[#fbfbfa] dark:bg-[#202020] space-y-3">
                      <div className="text-[11px] font-semibold text-[#37352f] dark:text-white flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <Sparkles size={12} className="text-[#2383e2]" />
                          <span>Personalizacja dokumentu: &quot;{msg.modeChoice.topic}&quot;</span>
                        </span>
                        <span className="text-[10px] text-[#787774] dark:text-[#9b9a97] font-normal">
                          Dopasuj lub wybierz natychmiast
                        </span>
                      </div>

                      {/* Kontrolki wyboru Stylu i Wyróżnień (KROK 3 - małe, zwięzłe kontrolki) */}
                      <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-[rgba(55,53,47,0.06)] dark:border-[rgba(255,255,255,0.06)]">
                        <div>
                          <label className="text-[10px] text-[#787774] dark:text-[#9b9a97] font-medium block mb-1">
                            Styl opracowania:
                          </label>
                          <select
                            value={customStyle}
                            onChange={(e) => setCustomStyle(e.target.value as NoteStyleOption)}
                            className="w-full text-xs p-1 rounded-[4px] border border-[rgba(55,53,47,0.15)] dark:border-[rgba(255,255,255,0.15)] bg-white dark:bg-[#191919] text-[#37352f] dark:text-white"
                          >
                            <option value="comprehensive">Kompendium analityczne</option>
                            <option value="school_student">Notatka szkolna (Pojęcia & Zapamiętaj)</option>
                            <option value="scientific_paper">Badanie naukowe (Metodologia)</option>
                            <option value="comparison_matrix">Porównanie (Macierz & Kryteria)</option>
                            <option value="historical_timeline">Oś czasu i fakty (Historia)</option>
                            <option value="visual_study">Studium wizualne z mediami</option>
                            <option value="executive">Raport wykonawczy (Executive)</option>
                            <option value="practical">Przewodnik wdrożeniowy (Action)</option>
                            <option value="personal_minimal">Minimalizm osobisty</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] text-[#787774] dark:text-[#9b9a97] font-medium block mb-1">
                            Co szczególnie wyróżnić:
                          </label>
                          <select
                            value={customFocus}
                            onChange={(e) => setCustomFocus(e.target.value as NoteFocusOption)}
                            className="w-full text-xs p-1 rounded-[4px] border border-[rgba(55,53,47,0.15)] dark:border-[rgba(255,255,255,0.15)] bg-white dark:bg-[#191919] text-[#37352f] dark:text-white"
                          >
                            <option value="highlights">Kluczowe wnioski i definicje</option>
                            <option value="diagrams_tables">Tabele danych i diagramy</option>
                            <option value="swot_risks">Analiza SWOT i ryzyk</option>
                            <option value="action_plan">Plan działania i checklisty</option>
                            <option value="pros_cons">Zalety i wady (Bilans)</option>
                            <option value="dates_events">Daty i sekwencje wydarzeń</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-[#787774] dark:text-[#9b9a97]">
                        <label className="flex items-center gap-1.5 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={includeQuestions}
                            onChange={(e) => setIncludeQuestions(e.target.checked)}
                            className="rounded text-[#2383e2]"
                          />
                          <span>Dodaj pytania kontrolne / quiz do powtórki</span>
                        </label>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-[rgba(55,53,47,0.06)] dark:border-[rgba(255,255,255,0.06)]">
                        <button
                          onClick={() => handleExecuteNoteCreation(msg.modeChoice!.topic, 'quick_note')}
                          className="p-2 rounded-[5px] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] bg-white dark:bg-[#191919] hover:border-[#2383e2] hover:bg-blue-50/20 text-left transition-all cursor-pointer group"
                        >
                          <div className="flex items-center gap-1.5 font-semibold text-xs text-[#37352f] dark:text-white group-hover:text-[#2383e2]">
                            <span>⚡</span>
                            <span>Szybkość (Instant 1s)</span>
                          </div>
                          <p className="text-[10px] text-[#787774] dark:text-[#9b9a97] mt-0.5 leading-normal">
                            Błyskawiczne utworzenie strony z dynamicznymi sekcjami i tabelą.
                          </p>
                        </button>
                        <button
                          onClick={() => handleExecuteNoteCreation(msg.modeChoice!.topic, 'deep_research')}
                          className="p-2 rounded-[5px] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] bg-white dark:bg-[#191919] hover:border-[#2383e2] hover:bg-purple-50/20 text-left transition-all cursor-pointer group"
                        >
                          <div className="flex items-center gap-1.5 font-semibold text-xs text-[#37352f] dark:text-white group-hover:text-purple-600">
                            <span>🔬</span>
                            <span>Precyzja (Deep 25s · 4+ źródła)</span>
                          </div>
                          <p className="text-[10px] text-[#787774] dark:text-[#9b9a97] mt-0.5 leading-normal">
                            Weryfikacja w 4 bazach (OpenAlex, Wikidata, Crossref, Web), eliminacja sprzeczności i ustrukturyzowana bibliografia.
                          </p>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* PROGRES BADANIA PRECYZYJNEGO (25s Live Timer) */}
                  {msg.isResearching && msg.researchProgress && (
                    <div className="ml-7 mt-2 p-3 rounded-[6px] border border-purple-200/80 dark:border-purple-800/60 bg-purple-50/40 dark:bg-purple-950/20 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 font-medium text-purple-900 dark:text-purple-200">
                          <span className="w-2 h-2 rounded-full bg-purple-600 animate-ping" />
                          <span>Krok {msg.researchProgress.step} z {msg.researchProgress.totalSteps}: {msg.researchProgress.stageName}</span>
                        </div>
                        <span className="text-[11px] font-mono text-purple-700 dark:text-purple-300 font-semibold">
                          Pozostało: {msg.researchProgress.secondsLeft}s
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-purple-100 dark:bg-purple-900/40 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-purple-600 transition-all duration-1000 ease-linear rounded-full"
                          style={{ width: `${msg.researchProgress.percent}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* KARTA DOKUMENTU I PRZYCISKI AKCJI */}
                  {(msg.pageId || (msg.generatedBlocks && msg.generatedBlocks.length > 0)) && (
                    <div className="ml-7 p-2.5 rounded-[6px] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] bg-[#fbfbfa] dark:bg-[#202020] space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2 truncate">
                          <span className="text-base">📄</span>
                          <div>
                            <div className="font-semibold text-[#37352f] dark:text-white truncate">
                              {msg.pageTitle || 'Gotowa notatka'}
                            </div>
                            <div className="text-[10px] text-[#787774] dark:text-[#9b9a97]">
                              {msg.generatedBlocks?.length || 8} bloków · Gotowa do edycji
                            </div>
                          </div>
                        </div>

                        {msg.pageId && (
                          <button
                            onClick={() => {
                              if (msg.pageId) {
                                setActivePageId(msg.pageId);
                                setActiveView('doc');
                              }
                            }}
                            className="px-2.5 py-1 bg-[#2383e2] hover:bg-[#1d6fc2] text-white rounded-[4px] text-[11px] font-medium cursor-pointer shrink-0 transition-colors shadow-2xs"
                          >
                            Otwórz w edytorze
                          </button>
                        )}
                      </div>

                      {/* Przyciski wstawiania do bieżącej strony lub nowej strony */}
                      <div className="flex items-center gap-1.5 pt-1 border-t border-[rgba(55,53,47,0.06)] dark:border-[rgba(255,255,255,0.06)]">
                        {activeDoc && msg.generatedBlocks && (
                          <button
                            onClick={() => handleInsertBlocksIntoCurrentDoc(msg.generatedBlocks)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-[3px] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] hover:bg-[rgba(55,53,47,0.04)] text-[11px] text-[#37352f] dark:text-[#d4d4d4] font-medium cursor-pointer transition-colors"
                          >
                            <span>➕</span>
                            <span>Wstaw do &quot;{activeDoc.title}&quot;</span>
                          </button>
                        )}

                        {!msg.pageId && msg.generatedBlocks && (
                          <button
                            onClick={() => handleCreatePageFromBlocks(msg.pageTitle || 'Notatka', msg.generatedBlocks)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-[3px] bg-[#2383e2] text-white text-[11px] font-medium cursor-pointer transition-colors shadow-2xs"
                          >
                            <span>📄</span>
                            <span>Otwórz jako nową stronę</span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Kopiowanie */}
                  <div className="ml-7 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handleCopyMessage(msg.id, msg.content)}
                      className="text-[10px] text-[#787774] hover:text-[#37352f] dark:hover:text-white flex items-center gap-1 cursor-pointer"
                    >
                      {copiedMessageId === msg.id ? <Check size={11} /> : <Copy size={11} />}
                      <span>{copiedMessageId === msg.id ? 'Skopiowano' : 'Kopiuj treść'}</span>
                    </button>

                    {msg.generatedBlocks && msg.generatedBlocks.length > 0 && (
                      <button
                        onClick={async () => {
                          const ok = await copyFullNoteToClipboard({
                            title: msg.pageTitle || 'Notatka',
                            blocks: msg.generatedBlocks || [],
                          });
                          if (ok) {
                            setCopiedDocId(msg.id);
                            setTimeout(() => setCopiedDocId(null), 2000);
                            addNotification('Skopiowano całą notatkę', 'Pełna treść Markdown/HTML trafiła do schowka.', 'success');
                          }
                        }}
                        className="text-[10px] text-[#2383e2] hover:underline flex items-center gap-1 cursor-pointer font-medium ml-2"
                      >
                        {copiedDocId === msg.id ? <Check size={11} /> : <Copy size={11} />}
                        <span>{copiedDocId === msg.id ? 'Skopiowano całą notatkę!' : 'Kopiuj całą notatkę (Markdown)'}</span>
                      </button>
                    )}
                  </div>

                  {/* Suggested Pills */}
                  {msg.suggestedPills && msg.suggestedPills.length > 0 && (
                    <div className="ml-7 flex flex-wrap gap-1 pt-1">
                      {msg.suggestedPills.map((pill, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSendMessage(pill)}
                          className="px-2 py-0.5 rounded-[4px] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] bg-white dark:bg-[#202020] hover:bg-[rgba(55,53,47,0.04)] text-[11px] text-[#787774] dark:text-[#9b9a97] hover:text-[#37352f] dark:hover:text-white cursor-pointer transition-colors"
                        >
                          {pill}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))
        )}

        {isTyping && (
          <div className="flex items-center gap-2 text-xs text-[#787774] dark:text-[#9b9a97] animate-pulse">
            <Sparkles size={13} className="text-[#2383e2] animate-spin" />
            <span>Asystent AI myśli...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* ========================================================================= */}
      {/* 3. STUDIO FLOATING BOTTOM INPUT CARD                                       */}
      {/* ========================================================================= */}
      <div className="p-3 border-t border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] bg-white dark:bg-[#191919] relative">
        <div className="border border-[rgba(55,53,47,0.14)] dark:border-[rgba(255,255,255,0.14)] rounded-[10px] bg-white dark:bg-[#202020] p-2.5 shadow-xs space-y-2">
          {/* Context Pill at top of card */}
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-[4px] bg-[rgba(55,53,47,0.06)] dark:bg-[rgba(255,255,255,0.08)] text-[11px] text-[#37352f] dark:text-[#d4d4d4] font-medium max-w-[280px] truncate">
              <span>{activeDoc?.icon || '📄'}</span>
              <span className="truncate">{activeDoc?.title || 'Nowa strona'}</span>
            </div>

            {/* Model Selector */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowModelDropdown(!showModelDropdown)}
                className="flex items-center gap-1 text-[11px] text-[#787774] dark:text-[#9b9a97] hover:text-[#37352f] dark:hover:text-white px-1.5 py-0.5 rounded cursor-pointer"
              >
                <span>{selectedModel}</span>
                <ChevronDown size={10} />
              </button>

              {showModelDropdown && (
                <div className="absolute right-0 bottom-full mb-1 bg-white dark:bg-[#252525] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] rounded-[6px] shadow-lg p-1 text-xs w-32 z-50">
                  {(['Auto', 'Claude 3.5', 'GPT-4o'] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => {
                        setSelectedModel(m);
                        setShowModelDropdown(false);
                      }}
                      className={`w-full text-left px-2 py-1 rounded-[4px] cursor-pointer flex items-center justify-between ${
                        selectedModel === m ? 'font-semibold text-[#2383e2]' : 'text-[#37352f] dark:text-[#d4d4d4] hover:bg-[rgba(55,53,47,0.04)]'
                      }`}
                    >
                      <span>{m}</span>
                      {selectedModel === m && <Check size={11} />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Textarea */}
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={handleInputChange}
            onKeyDown={handleTextareaKeyDown}
            placeholder="Napisz do Asystenta AI, np. „Stwórz notatkę o psach”..."
            className="w-full bg-transparent border-none focus:outline-none resize-none text-xs text-[#37352f] dark:text-white placeholder-[#9b9a97] leading-relaxed max-h-32 p-0"
          />

          {/* Bottom Toolbar: +, ✨, @ and Send Arrow Button */}
          <div className="flex items-center justify-between pt-1 border-t border-[rgba(55,53,47,0.06)] dark:border-[rgba(255,255,255,0.06)]">
            <div className="flex items-center gap-1 text-[#787774] dark:text-[#9b9a97]">
              <button
                type="button"
                onClick={() => setInput('')}
                className="p-1 hover:text-[#37352f] dark:hover:text-white hover:bg-[rgba(55,53,47,0.06)] rounded-[3px] cursor-pointer"
                title="Wyczyść pole"
              >
                <Plus size={13} />
              </button>
              <button
                type="button"
                onClick={() => setInput('/research ')}
                className="p-1 hover:text-[#37352f] dark:hover:text-white hover:bg-[rgba(55,53,47,0.06)] rounded-[3px] cursor-pointer"
                title="Zbadaj wieloźródłowo"
              >
                <Sparkles size={13} />
              </button>
              <button
                type="button"
                onClick={() => setInput('@')}
                className="p-1 hover:text-[#37352f] dark:hover:text-white hover:bg-[rgba(55,53,47,0.06)] rounded-[3px] cursor-pointer"
                title="Wspomnij"
              >
                <AtSign size={13} />
              </button>
            </div>

            <button
              onClick={() => handleSendMessage()}
              disabled={!input.trim()}
              className={`w-6 h-6 rounded-[4px] flex items-center justify-center transition-all cursor-pointer ${
                input.trim()
                  ? 'bg-[#2383e2] text-white hover:bg-[#1d6fc2] shadow-2xs'
                  : 'bg-[rgba(55,53,47,0.08)] dark:bg-[rgba(255,255,255,0.08)] text-[#9b9a97] cursor-not-allowed'
              }`}
            >
              <ArrowUp size={13} strokeWidth={2.5} />
            </button>
          </div>
        </div>
      </div>

      {/* Modal Wyboru Planów & Mock Payments (KROK 10, 11) */}
      <PlansModal
        isOpen={isPlansModalOpen}
        onClose={() => setIsPlansModalOpen(false)}
        highlightPro={true}
      />
    </div>
  );
};
