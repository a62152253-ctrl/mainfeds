import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  ArrowRight,
  ArrowLeft,
  Calendar,
  CheckCircle2,
  Search,
  Filter,
  GripVertical,
} from 'lucide-react';
import { TaskStatus, Priority, TaskItem } from '../types/workspace';
import { useWorkspace } from '../context/WorkspaceContext';

const COLUMNS: { id: TaskStatus; label: string; dotColor: string; badgeBg: string }[] = [
  { id: 'Do zrobienia', label: 'Do zrobienia', dotColor: 'bg-slate-400', badgeBg: 'bg-[rgba(55,53,47,0.08)] text-[#37352f] dark:text-[#d4d4d4]' },
  { id: 'W trakcie', label: 'W trakcie', dotColor: 'bg-blue-500', badgeBg: 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300' },
  { id: 'Zrobione', label: 'Zrobione', dotColor: 'bg-emerald-500', badgeBg: 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300' },
];

export const KanbanView: React.FC = () => {
  const { tasks, updateTaskStatus, addTask, deleteTask } = useWorkspace();
  const [showAddModal, setShowAddModal] = useState<TaskStatus | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState<Priority>('Średni');
  const [newDueDate, setNewDueDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newTag, setNewTag] = useState('Product');

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [dragOverCol, setDragOverCol] = useState<TaskStatus | null>(null);
  const [draggingTaskId, setDraggingTaskId] = useState<string | null>(null);

  const handleCreateTask = (status: TaskStatus) => {
    if (!newTitle.trim()) return;
    addTask({
      title: newTitle.trim(),
      status,
      priority: newPriority,
      dueDate: newDueDate,
      tag: newTag,
    });
    setNewTitle('');
    setShowAddModal(null);
  };

  const moveTask = (task: TaskItem, targetStatus: TaskStatus) => {
    updateTaskStatus(task.id, targetStatus);
  };

  // Filtered tasks
  const visibleTasks = tasks.filter((t) => {
    if (priorityFilter !== 'all' && t.priority !== priorityFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return t.title.toLowerCase().includes(q) || t.tag.toLowerCase().includes(q);
    }
    return true;
  });

  const doneCount = tasks.filter((t) => t.status === 'Zrobione').length;

  return (
    <div className="flex-1 h-full overflow-hidden bg-white dark:bg-[#191919] p-6 lg:p-8 flex flex-col text-[#37352f] dark:text-[#d4d4d4] transition-colors select-none">
      {/* Kanban Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] gap-4 shrink-0">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-[#787774] dark:text-[#9b9a97]">
            <span>Workspace</span>
            <span>/</span>
            <span className="font-semibold text-[#37352f] dark:text-white">Tablica Kanban</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-[#37352f] dark:text-white flex items-center gap-2.5 mt-1">
            <span>Zarządzanie Zadaniami</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[rgba(55,53,47,0.06)] dark:bg-[rgba(255,255,255,0.06)] text-[#787774] dark:text-[#9b9a97] font-mono font-normal tabular-nums">
              {tasks.length} zadań ({doneCount} ukończonych)
            </span>
          </h2>
        </div>

        <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
          {/* Search */}
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#787774] dark:text-[#9b9a97]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filtruj tablicę..."
              className="bg-[#fbfbfa] dark:bg-[#202020] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] rounded-[4px] pl-7 pr-3 py-1 text-xs text-[#37352f] dark:text-white placeholder-[#9b9a97] focus:outline-none focus:border-blue-500 w-36 sm:w-48"
            />
          </div>

          {/* Priority filter */}
          <div className="flex items-center gap-1 bg-[#fbfbfa] dark:bg-[#202020] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] px-2.5 py-1 rounded-[4px] text-xs text-[#37352f] dark:text-[#d4d4d4]">
            <Filter size={12} className="text-[#787774]" />
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="bg-transparent focus:outline-none text-[#37352f] dark:text-white font-medium cursor-pointer"
            >
              <option value="all">Wszystkie priorytety</option>
              <option value="Krytyczny">Krytyczny</option>
              <option value="Wysoki">Wysoki</option>
              <option value="Średni">Średni</option>
              <option value="Niski">Niski</option>
            </select>
          </div>

          <button
            onClick={() => setShowAddModal('Do zrobienia')}
            className="px-3 py-1 bg-[#2383e2] hover:bg-[#1d6fc2] text-white rounded-[4px] text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Plus size={14} />
            <span>Nowe zadanie</span>
          </button>
        </div>
      </div>

      {/* 3 Kanban Columns with Native HTML5 Drag and Drop */}
      <div className="flex-1 overflow-x-auto pt-4 flex gap-4 items-start">
        {COLUMNS.map((col) => {
          const colTasks = visibleTasks.filter((t) => t.status === col.id);
          const isOver = dragOverCol === col.id;

          return (
            <div
              key={col.id}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOverCol(col.id);
              }}
              onDragLeave={() => {
                setDragOverCol(null);
              }}
              onDrop={(e) => {
                e.preventDefault();
                const taskId = e.dataTransfer.getData('text/plain');
                if (taskId) {
                  updateTaskStatus(taskId, col.id);
                }
                setDragOverCol(null);
                setDraggingTaskId(null);
              }}
              className={`w-80 shrink-0 bg-[#fbfbfa] dark:bg-[#202020] border rounded-[6px] flex flex-col max-h-full transition-all ${
                isOver
                  ? 'border-[#2383e2] ring-1 ring-[#2383e2]'
                  : 'border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)]'
              }`}
            >
              {/* Column Header */}
              <div className="p-2.5 border-b border-[rgba(55,53,47,0.06)] dark:border-[rgba(255,255,255,0.06)] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${col.dotColor}`} />
                  <span className="text-xs font-semibold tracking-wider text-[#37352f] dark:text-[#d4d4d4] uppercase">
                    {col.label}
                  </span>
                  <span className="text-[10px] font-mono tabular-nums text-[#787774] dark:text-[#9b9a97] bg-white dark:bg-[#252525] px-1.5 py-0.2 rounded border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)]">
                    {colTasks.length}
                  </span>
                </div>

                <button
                  onClick={() => setShowAddModal(col.id)}
                  className="p-1 text-[#787774] hover:text-[#37352f] dark:hover:text-white rounded-[4px] hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.055)] cursor-pointer transition-colors"
                  title="Dodaj zadanie do tej kolumny"
                >
                  <Plus size={14} />
                </button>
              </div>

              {/* Cards Container */}
              <div className="flex-1 overflow-y-auto p-2.5 space-y-2">
                {colTasks.length === 0 ? (
                  <div className="text-center py-8 text-xs text-[#787774] dark:text-[#9b9a97] italic">
                    {isOver ? 'Upuść zadanie tutaj' : 'Brak zadań w tej kolumnie'}
                  </div>
                ) : (
                  colTasks.map((task) => {
                    const isDragging = draggingTaskId === task.id;

                    return (
                      <div
                        key={task.id}
                        draggable
                        onDragStart={(e) => {
                          e.dataTransfer.setData('text/plain', task.id);
                          setDraggingTaskId(task.id);
                        }}
                        onDragEnd={() => {
                          setDraggingTaskId(null);
                        }}
                        className={`p-3 bg-white dark:bg-[#252525] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] hover:border-[rgba(55,53,47,0.25)] dark:hover:border-[rgba(255,255,255,0.25)] rounded-[6px] space-y-2 group transition-all cursor-grab active:cursor-grabbing ${
                          isDragging ? 'opacity-40 scale-95 border-dashed border-[#2383e2]' : ''
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="text-xs font-medium text-[#37352f] dark:text-white leading-snug flex items-center gap-1.5">
                            <GripVertical size={12} className="text-[#787774] opacity-0 group-hover:opacity-100 shrink-0" />
                            <span>{task.title}</span>
                          </div>
                          <button
                            onClick={() => deleteTask(task.id)}
                            className="opacity-0 group-hover:opacity-100 p-1 text-[#787774] hover:text-rose-600 rounded transition-all cursor-pointer shrink-0"
                            title="Usuń zadanie"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>

                        {/* Metadata tags */}
                        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-[rgba(55,53,47,0.06)] dark:border-[rgba(255,255,255,0.06)]">
                          <span className="px-1.5 py-0.2 rounded-[3px] bg-[rgba(55,53,47,0.06)] dark:bg-[rgba(255,255,255,0.08)] text-[#787774] dark:text-[#9b9a97] font-mono text-[10px]">
                            #{task.tag}
                          </span>

                          <div className="flex items-center gap-2 text-[#787774] dark:text-[#9b9a97] font-mono text-[10px] tabular-nums">
                            <span
                              className={`px-1 py-0.2 rounded ${
                                task.priority === 'Krytyczny'
                                  ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 font-semibold'
                                  : task.priority === 'Wysoki'
                                  ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-300'
                                  : 'bg-[rgba(55,53,47,0.06)] dark:bg-[rgba(255,255,255,0.06)] text-[#787774]'
                              }`}
                            >
                              {task.priority}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar size={10} />
                              {task.dueDate}
                            </span>
                          </div>
                        </div>

                        {/* Quick Move Status Buttons */}
                        <div className="pt-1.5 flex items-center justify-between border-t border-[rgba(55,53,47,0.06)] dark:border-[rgba(255,255,255,0.06)] text-[10px] text-[#787774]">
                          {col.id !== 'Do zrobienia' && (
                            <button
                              onClick={() =>
                                moveTask(task, col.id === 'Zrobione' ? 'W trakcie' : 'Do zrobienia')
                              }
                              className="hover:text-[#37352f] dark:hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                            >
                              <ArrowLeft size={10} />
                              <span>Cofnij</span>
                            </button>
                          )}
                          {col.id !== 'Zrobione' && (
                            <button
                              onClick={() =>
                                moveTask(task, col.id === 'Do zrobienia' ? 'W trakcie' : 'Zrobione')
                              }
                              className="ml-auto hover:text-[#37352f] dark:hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                            >
                              <span>Dalej</span>
                              <ArrowRight size={10} />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#252525] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] rounded-[8px] max-w-sm w-full p-5 shadow-2xl space-y-3.5 text-xs text-[#37352f] dark:text-[#d4d4d4]">
            <h3 className="font-bold text-sm text-[#37352f] dark:text-white flex items-center gap-2">
              <Plus size={16} className="text-blue-600" />
              <span>Nowe zadanie ({showAddModal})</span>
            </h3>

            <div className="space-y-2.5">
              <div>
                <label className="text-[11px] text-[#787774] dark:text-[#9b9a97] block mb-1">Nazwa zadania:</label>
                <input
                  type="text"
                  autoFocus
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="np. Zaimplementować eksport..."
                  className="w-full bg-[#f7f6f3] dark:bg-[#191919] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] p-2 rounded-[4px] text-[#37352f] dark:text-white placeholder-[#9b9a97] focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] text-[#787774] dark:text-[#9b9a97] block mb-1">Priorytet:</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as Priority)}
                    className="w-full bg-[#f7f6f3] dark:bg-[#191919] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] p-1.5 rounded-[4px] text-[#37352f] dark:text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Niski">Niski</option>
                    <option value="Średni">Średni</option>
                    <option value="Wysoki">Wysoki</option>
                    <option value="Krytyczny">Krytyczny</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-[#787774] dark:text-[#9b9a97] block mb-1">Tag:</label>
                  <input
                    type="text"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    className="w-full bg-[#f7f6f3] dark:bg-[#191919] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] p-1.5 rounded-[4px] text-[#37352f] dark:text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] text-[#787774] dark:text-[#9b9a97] block mb-1">Termin:</label>
                <input
                  type="date"
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  className="w-full bg-[#f7f6f3] dark:bg-[#191919] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] p-1.5 rounded-[4px] text-[#37352f] dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAddModal(null)}
                className="px-3 py-1.5 bg-[#f7f6f3] dark:bg-[#191919] hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.06)] text-[#37352f] dark:text-[#d4d4d4] rounded-[4px] cursor-pointer transition-colors"
              >
                Anuluj
              </button>
              <button
                onClick={() => handleCreateTask(showAddModal)}
                className="px-3.5 py-1.5 bg-[#2383e2] hover:bg-[#1d6fc2] text-white rounded-[4px] font-semibold cursor-pointer transition-colors"
              >
                Dodaj zadanie
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
