import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Calendar as CalendarIcon,
  CheckCircle2,
  Clock,
  Plus,
  X,
  Filter,
  AlertTriangle,
} from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { Priority, TaskStatus } from '../types/workspace';

export const CalendarView: React.FC = () => {
  const { tasks, updateTaskStatus, addTask } = useWorkspace();
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [quickAddDay, setQuickAddDay] = useState<string | null>(null);
  const [quickTaskTitle, setQuickTaskTitle] = useState('');
  const [quickTaskPriority, setQuickTaskPriority] = useState<Priority>('Średni');

  const monthNames = [
    'Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec',
    'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'
  ];

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = (new Date(year, month, 1).getDay() + 6) % 7; // Monday = 0

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  const daysArray = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const blankDays = Array.from({ length: firstDayIndex }, (_, i) => i);

  const realToday = new Date();

  // Month stats
  const formattedMonthPrefix = `${year}-${month + 1 < 10 ? `0${month + 1}` : `${month + 1}`}`;
  const monthTasks = tasks.filter((t) => t.dueDate.startsWith(formattedMonthPrefix));
  const monthDoneCount = monthTasks.filter((t) => t.status === 'Zrobione').length;

  const handleCreateQuickTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTaskTitle.trim() || !quickAddDay) return;
    addTask({
      title: quickTaskTitle.trim(),
      status: 'Do zrobienia',
      priority: quickTaskPriority,
      dueDate: quickAddDay,
      tag: 'Sprint',
    });
    setQuickTaskTitle('');
    setQuickAddDay(null);
  };

  return (
    <div className="flex-1 h-full overflow-hidden bg-white dark:bg-[#191919] p-6 lg:p-8 flex flex-col text-[#37352f] dark:text-[#d4d4d4] font-sans">
      {/* Calendar Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] gap-4 shrink-0">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-[#787774] dark:text-[#9b9a97]">
            <span className="hover:text-[#37352f] dark:hover:text-white cursor-pointer">Workspace</span>
            <span>/</span>
            <span className="text-[#37352f] dark:text-[#d4d4d4] font-medium">Kalendarz Zadań</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-[#37352f] dark:text-white flex items-center gap-2.5 mt-1">
            <span>📅 Harmonogram i Terminy</span>
            <span className="text-xs px-2 py-0.5 rounded-[4px] bg-[rgba(55,53,47,0.06)] dark:bg-[rgba(255,255,255,0.08)] text-[#787774] dark:text-[#9b9a97] font-normal">
              {monthNames[month]} {year}
            </span>
          </h2>
          <p className="text-xs text-[#787774] dark:text-[#9b9a97] mt-1">
            Zaplanowano {monthTasks.length} zadań w tym miesiącu ({monthDoneCount} ukończonych).
          </p>
        </div>

        {/* Month Navigation, Filter & Today Button */}
        <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
          {/* Filter Priority */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-[#202020] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] px-2.5 py-1 rounded-[4px] text-xs">
            <Filter size={12} className="text-[#787774] dark:text-[#9b9a97]" />
            <select
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value)}
              className="bg-transparent text-[#37352f] dark:text-[#d4d4d4] text-xs focus:outline-none cursor-pointer"
            >
              <option value="all">Wszystkie priorytety</option>
              <option value="Krytyczny">Krytyczny</option>
              <option value="Wysoki">Wysoki</option>
              <option value="Średni">Średni</option>
              <option value="Niski">Niski</option>
            </select>
          </div>

          <button
            onClick={handleToday}
            className="px-2.5 py-1 bg-white dark:bg-[#202020] hover:bg-[rgba(55,53,47,0.04)] dark:hover:bg-[rgba(255,255,255,0.055)] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] rounded-[4px] text-xs text-[#37352f] dark:text-[#d4d4d4] cursor-pointer transition-colors"
          >
            Dziś
          </button>

          <div className="flex items-center bg-white dark:bg-[#202020] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] rounded-[4px] p-0.5">
            <button
              onClick={handlePrevMonth}
              className="p-1 hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.08)] rounded-[3px] text-[#787774] dark:text-[#9b9a97] hover:text-[#37352f] dark:hover:text-white cursor-pointer transition-colors"
              title="Poprzedni miesiąc"
            >
              <ChevronLeft size={14} />
            </button>
            <span className="text-xs font-medium px-2.5 min-w-28 text-center text-[#37352f] dark:text-[#d4d4d4]">
              {monthNames[month]} {year}
            </span>
            <button
              onClick={handleNextMonth}
              className="p-1 hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.08)] rounded-[3px] text-[#787774] dark:text-[#9b9a97] hover:text-[#37352f] dark:hover:text-white cursor-pointer transition-colors"
              title="Następny miesiąc"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Days of Week Header */}
      <div className="grid grid-cols-7 gap-px bg-[rgba(55,53,47,0.09)] dark:bg-[rgba(255,255,255,0.094)] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] rounded-t-[4px] mt-4 text-center text-[11px] font-medium text-[#787774] dark:text-[#9b9a97] select-none overflow-hidden">
        {['Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota', 'Niedziela'].map((d) => (
          <div key={d} className="bg-[#fbfbfa] dark:bg-[#202020] py-2">
            {d}
          </div>
        ))}
      </div>

      {/* Calendar Days Grid */}
      <div className="flex-1 grid grid-cols-7 gap-px bg-[rgba(55,53,47,0.09)] dark:bg-[rgba(255,255,255,0.094)] border-x border-b border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] rounded-b-[4px] overflow-y-auto">
        {blankDays.map((_, idx) => (
          <div key={`blank-${idx}`} className="bg-[#fbfbfa]/60 dark:bg-[#1e1e1e] min-h-24 p-2 opacity-40" />
        ))}

        {daysArray.map((day) => {
          const formattedDay = day < 10 ? `0${day}` : `${day}`;
          const formattedMonth = month + 1 < 10 ? `0${month + 1}` : `${month + 1}`;
          const dateString = `${year}-${formattedMonth}-${formattedDay}`;

          const dayTasks = tasks
            .filter((t) => t.dueDate === dateString)
            .filter((t) => (filterPriority === 'all' ? true : t.priority === filterPriority));

          const isToday =
            realToday.getDate() === day &&
            realToday.getMonth() === month &&
            realToday.getFullYear() === year;

          return (
            <div
              key={day}
              className={`bg-white dark:bg-[#191919] min-h-24 p-2 flex flex-col justify-between hover:bg-[rgba(55,53,47,0.02)] dark:hover:bg-[rgba(255,255,255,0.03)] transition-colors relative group ${
                isToday ? 'bg-blue-50/20 dark:bg-blue-950/10' : ''
              }`}
            >
              <div className="flex items-center justify-between">
                <span
                  className={`text-xs ${
                    isToday
                      ? 'w-5 h-5 rounded-full bg-[#2383e2] text-white flex items-center justify-center font-medium shadow-2xs text-[11px]'
                      : 'text-[#787774] dark:text-[#9b9a97]'
                  }`}
                >
                  {day}
                </span>

                <button
                  onClick={() => setQuickAddDay(dateString)}
                  className="opacity-0 group-hover:opacity-100 p-0.5 text-[#787774] hover:text-[#37352f] dark:hover:text-white rounded-[3px] hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.08)] cursor-pointer transition-all"
                  title="Dodaj zadanie z tą datą"
                >
                  <Plus size={12} />
                </button>
              </div>

              {/* Tasks list in this day */}
              <div className="space-y-1 mt-1 overflow-y-auto max-h-24">
                {dayTasks.map((t) => (
                  <div
                    key={t.id}
                    onClick={() =>
                      updateTaskStatus(t.id, t.status === 'Zrobione' ? 'Do zrobienia' : 'Zrobione')
                    }
                    className={`px-1.5 py-0.5 rounded-[3px] text-[10px] font-normal truncate cursor-pointer transition-all flex items-center justify-between border ${
                      t.status === 'Zrobione'
                        ? 'bg-[rgba(55,53,47,0.04)] dark:bg-[rgba(255,255,255,0.04)] text-[#9b9a97] border-[rgba(55,53,47,0.06)] line-through'
                        : t.priority === 'Krytyczny'
                        ? 'bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800'
                        : t.priority === 'Wysoki'
                        ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                        : 'bg-[#f1f1ef] dark:bg-[#262626] text-[#37352f] dark:text-[#d4d4d4] border-[rgba(55,53,47,0.08)] dark:border-[rgba(255,255,255,0.08)] hover:bg-[rgba(55,53,47,0.08)]'
                    }`}
                    title={`${t.title} (${t.status}) - Priorytet: ${t.priority}. Kliknij aby przełączyć status.`}
                  >
                    <span className="truncate">• {t.title}</span>
                    <span className="text-[9px] opacity-80 shrink-0 ml-1">
                      {t.status === 'Zrobione' ? '✓' : ''}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Add Task Modal */}
      {quickAddDay && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-[#202020] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] rounded-[8px] max-w-sm w-full p-5 shadow-2xl space-y-4 text-xs text-[#37352f] dark:text-[#d4d4d4]">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm text-[#37352f] dark:text-white flex items-center gap-2">
                <Plus size={15} className="text-[#2383e2]" />
                <span>Nowe zadanie ({quickAddDay})</span>
              </h3>
              <button
                onClick={() => setQuickAddDay(null)}
                className="p-1 rounded-[4px] text-[#787774] hover:text-[#37352f] dark:hover:text-white hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.08)]"
              >
                <X size={14} />
              </button>
            </div>

            <form onSubmit={handleCreateQuickTask} className="space-y-3">
              <div>
                <label className="text-[11px] font-medium text-[#787774] dark:text-[#9b9a97] block mb-1">
                  Tytuł zadania:
                </label>
                <input
                  type="text"
                  autoFocus
                  value={quickTaskTitle}
                  onChange={(e) => setQuickTaskTitle(e.target.value)}
                  placeholder="np. Przygotować raport kwartalny..."
                  className="w-full bg-[rgba(55,53,47,0.02)] dark:bg-[#191919] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] p-2 rounded-[4px] text-[#37352f] dark:text-white placeholder:text-[#787774] focus:outline-none focus:border-[#2383e2]"
                />
              </div>

              <div>
                <label className="text-[11px] font-medium text-[#787774] dark:text-[#9b9a97] block mb-1">
                  Priorytet:
                </label>
                <select
                  value={quickTaskPriority}
                  onChange={(e) => setQuickTaskPriority(e.target.value as Priority)}
                  className="w-full bg-[rgba(55,53,47,0.02)] dark:bg-[#191919] border border-[rgba(55,53,47,0.12)] dark:border-[rgba(255,255,255,0.12)] p-2 rounded-[4px] text-[#37352f] dark:text-[#d4d4d4] focus:outline-none focus:border-[#2383e2]"
                >
                  <option value="Niski">Niski</option>
                  <option value="Średni">Średni</option>
                  <option value="Wysoki">Wysoki</option>
                  <option value="Krytyczny">Krytyczny</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setQuickAddDay(null)}
                  className="px-3 py-1.5 bg-transparent hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.08)] text-[#787774] dark:text-[#9b9a97] rounded-[4px] cursor-pointer"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-[#2383e2] hover:bg-[#1d6fc2] text-white rounded-[4px] font-medium cursor-pointer shadow-xs"
                >
                  Zapisz termin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
