import React, { useState } from 'react';
import {
  Table as TableIcon,
  Columns3,
  Calendar as CalendarIcon,
  List as ListIcon,
  LayoutGrid,
  Plus,
  ArrowUpDown,
  Filter,
  Trash2,
  Calendar,
  Search,
  CheckCircle2,
  Circle,
  Download,
  CheckSquare,
  Square,
  Sparkles,
  ExternalLink,
  Clock,
  User,
  Tag,
  Link,
  ChevronLeft,
  ChevronRight,
  X,
  Edit2,
  MoreHorizontal,
} from 'lucide-react';
import { TaskItem, TaskStatus, Priority } from '../types/workspace';
import { useWorkspace } from '../context/WorkspaceContext';

const PRIORITY_ORDER: Record<Priority, number> = {
  Krytyczny: 4,
  Wysoki: 3,
  Średni: 2,
  Niski: 1,
};

const STATUS_COLUMNS: TaskStatus[] = ['Do zrobienia', 'W trakcie', 'Zrobione'];

export type DatabaseViewType = 'table' | 'kanban' | 'calendar' | 'list' | 'gallery';

export const DatabaseView: React.FC = () => {
  const { tasks, updateTask, updateTaskStatus, addTask, deleteTask, pages } = useWorkspace();
  const [viewMode, setViewMode] = useState<DatabaseViewType>('table');
  const [filterTag, setFilterTag] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortField, setSortField] = useState<'title' | 'dueDate' | 'priority' | 'status' | 'estimatedHours'>('dueDate');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [selectedTaskIds, setSelectedTaskIds] = useState<string[]>([]);
  const [activeRecord, setActiveRecord] = useState<TaskItem | null>(null);

  // Calendar month state
  const [currentCalendarDate, setCurrentCalendarDate] = useState<Date>(new Date());

  const handleSortChange = (field: 'title' | 'dueDate' | 'priority' | 'status' | 'estimatedHours') => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const filteredTasks = tasks
    .filter((t) => (filterTag === 'all' ? true : t.tag === filterTag))
    .filter((t) => (filterStatus === 'all' ? true : t.status === filterStatus))
    .filter((t) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        t.title.toLowerCase().includes(q) ||
        t.tag.toLowerCase().includes(q) ||
        (t.assignee && t.assignee.toLowerCase().includes(q)) ||
        (t.description && t.description.toLowerCase().includes(q))
      );
    })
    .sort((a, b) => {
      let comparison = 0;
      if (sortField === 'title') {
        comparison = a.title.localeCompare(b.title);
      } else if (sortField === 'dueDate') {
        comparison = a.dueDate.localeCompare(b.dueDate);
      } else if (sortField === 'priority') {
        comparison = (PRIORITY_ORDER[b.priority] || 0) - (PRIORITY_ORDER[a.priority] || 0);
      } else if (sortField === 'status') {
        comparison = a.status.localeCompare(b.status);
      } else if (sortField === 'estimatedHours') {
        comparison = (a.estimatedHours || 0) - (b.estimatedHours || 0);
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  const allTags = Array.from(new Set(tasks.map((t) => t.tag))).filter(Boolean);

  const handleAddNewRow = (status: TaskStatus = 'Do zrobienia', defaultDate?: string) => {
    addTask({
      title: 'Nowy rekord bazy',
      status,
      priority: 'Średni',
      dueDate: defaultDate || new Date().toISOString().split('T')[0],
      tag: allTags[0] || 'Ogólne',
      assignee: 'Ty',
      estimatedHours: 2,
      isCompleted: status === 'Zrobione',
    });
  };

  const handleToggleCompleted = (task: TaskItem) => {
    const nextCompleted = !task.isCompleted;
    updateTask(task.id, {
      isCompleted: nextCompleted,
      status: nextCompleted ? 'Zrobione' : 'Do zrobienia',
    });
  };

  // Export to CSV
  const handleExportCsv = () => {
    const headers = ['ID', 'Tytuł', 'Status', 'Priorytet', 'Tag', 'Termin', 'Osoba', 'Godziny', 'URL'];
    const rows = filteredTasks.map((t) => [
      t.id,
      `"${t.title.replace(/"/g, '""')}"`,
      t.status,
      t.priority,
      t.tag,
      t.dueDate,
      t.assignee || '',
      t.estimatedHours || 0,
      t.url || '',
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `baza-danych-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Export to JSON
  const handleExportJson = () => {
    const jsonContent = JSON.stringify(filteredTasks, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `baza-danych-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Batch actions
  const handleSelectAll = () => {
    if (selectedTaskIds.length === filteredTasks.length) {
      setSelectedTaskIds([]);
    } else {
      setSelectedTaskIds(filteredTasks.map((t) => t.id));
    }
  };

  const handleBatchMarkDone = () => {
    selectedTaskIds.forEach((id) => {
      updateTask(id, { status: 'Zrobione', isCompleted: true });
    });
    setSelectedTaskIds([]);
  };

  const handleBatchDelete = () => {
    if (confirm(`Czy na pewno chcesz usunąć ${selectedTaskIds.length} zaznaczonych rekordów?`)) {
      selectedTaskIds.forEach((id) => deleteTask(id));
      setSelectedTaskIds([]);
    }
  };

  return (
    <div className="flex-1 h-full overflow-hidden bg-white dark:bg-[#191919] p-4 sm:p-6 lg:p-8 flex flex-col text-[#37352f] dark:text-[#d4d4d4] transition-colors select-none">
      {/* 1. Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] gap-3 shrink-0">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-[#787774] dark:text-[#9b9a97]">
            <span>Workspace</span>
            <span>/</span>
            <span className="font-semibold text-[#37352f] dark:text-white">Baza Danych & Tabele</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#37352f] dark:text-white flex items-center gap-2 mt-0.5">
            <span>Baza Projektu</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[rgba(55,53,47,0.06)] dark:bg-[rgba(255,255,255,0.06)] text-[#787774] dark:text-[#9b9a97] font-mono font-normal tabular-nums">
              {filteredTasks.length} z {tasks.length}
            </span>
          </h2>
        </div>

        {/* View Switcher Tabs (Table, Kanban, Calendar, List, Gallery) */}
        <div className="flex items-center gap-0.5 self-start sm:self-auto">
          {[
            { id: 'table', label: 'Tabela', icon: <TableIcon size={13} /> },
            { id: 'kanban', label: 'Kanban', icon: <Columns3 size={13} /> },
            { id: 'calendar', label: 'Kalendarz', icon: <CalendarIcon size={13} /> },
            { id: 'list', label: 'Lista', icon: <ListIcon size={13} /> },
            { id: 'gallery', label: 'Galeria', icon: <LayoutGrid size={13} /> },
          ].map((v) => (
            <button
              key={v.id}
              onClick={() => setViewMode(v.id as DatabaseViewType)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-medium cursor-pointer transition-colors ${
                viewMode === v.id
                  ? 'bg-[rgba(55,53,47,0.08)] dark:bg-[rgba(255,255,255,0.08)] text-[#37352f] dark:text-white font-semibold'
                  : 'text-[#787774] dark:text-[#9b9a97] hover:text-[#37352f] dark:hover:text-white hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.055)]'
              }`}
            >
              {v.icon}
              <span className="hidden md:inline">{v.label}</span>
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          <button
            onClick={handleExportCsv}
            className="px-2.5 py-1 bg-white dark:bg-[#202020] hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.06)] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] text-[#37352f] dark:text-[#d4d4d4] rounded-[4px] text-xs font-medium flex items-center gap-1 cursor-pointer transition-colors"
            title="Eksportuj do CSV"
          >
            <Download size={12} />
            <span className="hidden sm:inline">CSV</span>
          </button>
          <button
            onClick={handleExportJson}
            className="px-2.5 py-1 bg-white dark:bg-[#202020] hover:bg-[rgba(55,53,47,0.06)] dark:hover:bg-[rgba(255,255,255,0.06)] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] text-[#37352f] dark:text-[#d4d4d4] rounded-[4px] text-xs font-medium flex items-center gap-1 cursor-pointer transition-colors"
            title="Eksportuj do JSON"
          >
            <Download size={12} />
            <span className="hidden sm:inline">JSON</span>
          </button>
          <button
            onClick={() => handleAddNewRow()}
            className="px-3 py-1 bg-[#2383e2] hover:bg-[#1d6fc2] text-white rounded-[4px] text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Plus size={14} />
            <span>Nowy rekord</span>
          </button>
        </div>
      </div>

      {/* 2. Filter Bar */}
      <div className="py-2.5 flex flex-wrap items-center justify-between gap-2.5 shrink-0">
        <div className="flex flex-wrap items-center gap-2">
          {/* Search Input */}
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#787774] dark:text-[#9b9a97]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filtruj rekordy..."
              className="bg-[#fbfbfa] dark:bg-[#202020] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] rounded-[4px] pl-7 pr-3 py-1 text-xs text-[#37352f] dark:text-white placeholder-[#9b9a97] focus:outline-none focus:border-blue-500 w-40 sm:w-52"
            />
          </div>

          {/* Tag Filter */}
          <select
            value={filterTag}
            onChange={(e) => setFilterTag(e.target.value)}
            className="bg-[#fbfbfa] dark:bg-[#202020] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] rounded-[4px] px-2.5 py-1 text-xs text-[#37352f] dark:text-[#d4d4d4] focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="all">Wszystkie tagi</option>
            {allTags.map((tag) => (
              <option key={tag} value={tag}>
                #{tag}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-[#fbfbfa] dark:bg-[#202020] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] rounded-[4px] px-2.5 py-1 text-xs text-[#37352f] dark:text-[#d4d4d4] focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="all">Wszystkie statusy</option>
            <option value="Do zrobienia">Do zrobienia</option>
            <option value="W trakcie">W trakcie</option>
            <option value="Zrobione">Zrobione</option>
          </select>
        </div>

        {/* Batch selection bar */}
        {selectedTaskIds.length > 0 && (
          <div className="flex items-center gap-2 bg-[rgba(35,131,226,0.1)] border border-[rgba(35,131,226,0.25)] px-2.5 py-1 rounded-[4px] text-xs text-[#2383e2] dark:text-[#529cca] font-medium">
            <span>Wybrano: {selectedTaskIds.length}</span>
            <button
              onClick={handleBatchMarkDone}
              className="px-2 py-0.5 rounded-[3px] bg-[#2383e2] text-white font-semibold cursor-pointer hover:bg-[#1d6fc2] text-[11px]"
            >
              Oznacz jako zrobione
            </button>
            <button
              onClick={handleBatchDelete}
              className="p-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded cursor-pointer"
              title="Usuń zaznaczone"
            >
              <Trash2 size={13} />
            </button>
          </div>
        )}
      </div>

      {/* 3. View Content Container */}
      <div className="flex-1 overflow-auto rounded-[4px] border border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] bg-white dark:bg-[#191919]">
        {/* VIEW 1: TABLE */}
        {viewMode === 'table' && (
          <div className="overflow-x-auto h-full">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#fbfbfa] dark:bg-[#202020] border-b border-[rgba(55,53,47,0.09)] dark:border-[rgba(255,255,255,0.094)] sticky top-0 z-10 text-[#787774] dark:text-[#9b9a97] font-medium text-[11px]">
                <tr>
                  <th className="p-2.5 w-8">
                    <button onClick={handleSelectAll} className="cursor-pointer">
                      {selectedTaskIds.length === filteredTasks.length && filteredTasks.length > 0 ? (
                        <CheckSquare size={14} className="text-blue-600" />
                      ) : (
                        <Square size={14} className="text-[#787774]" />
                      )}
                    </button>
                  </th>
                  <th className="p-3 min-w-[200px] cursor-pointer" onClick={() => handleSortChange('title')}>
                    <div className="flex items-center gap-1">
                      <span>Tytuł</span>
                      <ArrowUpDown size={11} />
                    </div>
                  </th>
                  <th className="p-3 min-w-[120px] cursor-pointer" onClick={() => handleSortChange('status')}>
                    <div className="flex items-center gap-1">
                      <span>Status</span>
                      <ArrowUpDown size={11} />
                    </div>
                  </th>
                  <th className="p-3 min-w-[100px] cursor-pointer" onClick={() => handleSortChange('priority')}>
                    <div className="flex items-center gap-1">
                      <span>Priorytet</span>
                      <ArrowUpDown size={11} />
                    </div>
                  </th>
                  <th className="p-3 min-w-[110px]">Tag</th>
                  <th className="p-3 min-w-[110px] cursor-pointer" onClick={() => handleSortChange('dueDate')}>
                    <div className="flex items-center gap-1">
                      <span>Termin</span>
                      <ArrowUpDown size={11} />
                    </div>
                  </th>
                  <th className="p-3 min-w-[100px]">Przypisane</th>
                  <th className="p-3 min-w-[80px] cursor-pointer" onClick={() => handleSortChange('estimatedHours')}>
                    <div className="flex items-center gap-1">
                      <span>Godziny</span>
                      <ArrowUpDown size={11} />
                    </div>
                  </th>
                  <th className="p-3 text-right">Akcje</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                {filteredTasks.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-400 italic">
                      Brak rekordów pasujących do filtra.
                    </td>
                  </tr>
                ) : (
                  filteredTasks.map((task) => (
                    <tr
                      key={task.id}
                      className="hover:bg-slate-50/70 dark:hover:bg-slate-850/50 transition-colors group cursor-pointer"
                      onClick={() => setActiveRecord(task)}
                    >
                      <td className="p-3" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => {
                            setSelectedTaskIds((prev) =>
                              prev.includes(task.id) ? prev.filter((id) => id !== task.id) : [...prev, task.id]
                            );
                          }}
                          className="cursor-pointer"
                        >
                          {selectedTaskIds.includes(task.id) ? (
                            <CheckSquare size={14} className="text-blue-600" />
                          ) : (
                            <Square size={14} className="text-slate-400" />
                          )}
                        </button>
                      </td>

                      <td className="p-3 font-semibold text-slate-900 dark:text-white" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="text"
                          value={task.title}
                          onChange={(e) => updateTask(task.id, { title: e.target.value })}
                          className="bg-transparent border-none outline-none w-full text-slate-900 dark:text-white font-medium focus:ring-1 focus:ring-blue-500 rounded px-1"
                        />
                      </td>

                      <td className="p-3" onClick={(e) => e.stopPropagation()}>
                        <select
                          value={task.status}
                          onChange={(e) => {
                            const newStatus = e.target.value as TaskStatus;
                            updateTask(task.id, {
                              status: newStatus,
                              isCompleted: newStatus === 'Zrobione',
                            });
                          }}
                          className={`text-xs font-semibold px-2 py-0.5 rounded-full border cursor-pointer ${
                            task.status === 'Zrobione'
                              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                              : task.status === 'W trakcie'
                              ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          <option value="Do zrobienia">Do zrobienia</option>
                          <option value="W trakcie">W trakcie</option>
                          <option value="Zrobione">Zrobione</option>
                        </select>
                      </td>

                      <td className="p-3" onClick={(e) => e.stopPropagation()}>
                        <select
                          value={task.priority}
                          onChange={(e) => updateTask(task.id, { priority: e.target.value as Priority })}
                          className="text-[11px] font-medium bg-transparent border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-0.5 cursor-pointer"
                        >
                          <option value="Niski">Niski</option>
                          <option value="Średni">Średni</option>
                          <option value="Wysoki">Wysoki</option>
                          <option value="Krytyczny">Krytyczny</option>
                        </select>
                      </td>

                      <td className="p-3" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="text"
                          value={task.tag}
                          onChange={(e) => updateTask(task.id, { tag: e.target.value })}
                          className="bg-transparent border border-slate-200/60 dark:border-slate-700 rounded px-1.5 py-0.5 text-[11px] font-mono text-blue-600 dark:text-blue-400 w-24"
                        />
                      </td>

                      <td className="p-3 font-mono text-[11px]" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="date"
                          value={task.dueDate}
                          onChange={(e) => updateTask(task.id, { dueDate: e.target.value })}
                          className="bg-transparent border-none outline-none text-slate-600 dark:text-slate-300 text-[11px] font-mono cursor-pointer"
                        />
                      </td>

                      <td className="p-3" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="text"
                          value={task.assignee || ''}
                          onChange={(e) => updateTask(task.id, { assignee: e.target.value })}
                          className="bg-transparent border-none outline-none text-[11px] text-slate-700 dark:text-slate-300 w-20"
                        />
                      </td>

                      <td className="p-3 font-mono text-[11px]" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="number"
                          value={task.estimatedHours || 0}
                          onChange={(e) => updateTask(task.id, { estimatedHours: Number(e.target.value) })}
                          className="bg-transparent border-none outline-none text-slate-600 dark:text-slate-400 w-12"
                        />
                      </td>

                      <td className="p-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => setActiveRecord(task)}
                            className="p-1 hover:text-blue-600 rounded cursor-pointer"
                            title="Szczegóły"
                          >
                            <Edit2 size={13} />
                          </button>
                          <button
                            onClick={() => deleteTask(task.id)}
                            className="p-1 hover:text-rose-600 rounded cursor-pointer"
                            title="Usuń"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* VIEW 2: KANBAN BOARD */}
        {viewMode === 'kanban' && (
          <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 h-full overflow-y-auto">
            {STATUS_COLUMNS.map((status) => {
              const colTasks = filteredTasks.filter((t) => t.status === status);

              return (
                <div
                  key={status}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const taskId = e.dataTransfer.getData('text/plain');
                    if (taskId) {
                      updateTask(taskId, {
                        status,
                        isCompleted: status === 'Zrobione',
                      });
                    }
                  }}
                  className="flex flex-col bg-slate-50 dark:bg-slate-850/60 rounded-2xl p-3 border border-slate-200/80 dark:border-slate-800 max-h-[calc(100vh-220px)]"
                >
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200/80 dark:border-slate-700/80">
                    <div className="flex items-center gap-1.5 font-bold text-xs text-slate-800 dark:text-slate-200">
                      <span>{status}</span>
                      <span className="w-5 h-5 rounded-full bg-slate-200/80 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[10px] flex items-center justify-center font-mono">
                        {colTasks.length}
                      </span>
                    </div>
                    <button
                      onClick={() => handleAddNewRow(status)}
                      className="p-1 hover:text-blue-600 rounded cursor-pointer text-slate-400"
                    >
                      <Plus size={14} />
                    </button>
                  </div>

                  <div className="space-y-2 overflow-y-auto flex-1 pr-1">
                    {colTasks.map((task) => (
                      <div
                        key={task.id}
                        draggable
                        onDragStart={(e) => e.dataTransfer.setData('text/plain', task.id)}
                        onClick={() => setActiveRecord(task)}
                        className="p-3 bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl shadow-2xs hover:shadow-sm cursor-grab active:cursor-grabbing transition-all group"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="font-semibold text-xs text-slate-900 dark:text-white line-clamp-2">
                            {task.title}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteTask(task.id);
                            }}
                            className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-600 p-0.5"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>

                        <div className="flex items-center justify-between mt-3 text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                          <span className="px-1.5 py-0.2 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-[10px]">
                            #{task.tag}
                          </span>
                          <span className="text-[10px]">{task.dueDate}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW 3: CALENDAR */}
        {viewMode === 'calendar' && (
          <div className="p-4 flex flex-col h-full overflow-y-auto">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                {currentCalendarDate.toLocaleDateString('pl-PL', { month: 'long', year: 'numeric' })}
              </h3>
              <div className="flex items-center gap-1">
                <button
                  onClick={() =>
                    setCurrentCalendarDate(
                      new Date(currentCalendarDate.getFullYear(), currentCalendarDate.getMonth() - 1, 1)
                    )
                  }
                  className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                >
                  <ChevronLeft size={16} />
                </button>
                <button
                  onClick={() => setCurrentCalendarDate(new Date())}
                  className="px-2 py-0.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700"
                >
                  Dziś
                </button>
                <button
                  onClick={() =>
                    setCurrentCalendarDate(
                      new Date(currentCalendarDate.getFullYear(), currentCalendarDate.getMonth() + 1, 1)
                    )
                  }
                  className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-px bg-slate-200 dark:bg-slate-800 rounded-xl overflow-hidden flex-1 border border-slate-200 dark:border-slate-800">
              {['Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So', 'Nd'].map((day) => (
                <div
                  key={day}
                  className="bg-slate-50 dark:bg-slate-850 p-2 text-center text-[10px] font-bold text-slate-400"
                >
                  {day}
                </div>
              ))}

              {Array.from({ length: 35 }).map((_, i) => {
                const year = currentCalendarDate.getFullYear();
                const month = currentCalendarDate.getMonth();
                const firstDayIndex = (new Date(year, month, 1).getDay() + 6) % 7;
                const dayNumber = i - firstDayIndex + 1;
                const dateObj = new Date(year, month, dayNumber);
                const dateStr = dateObj.toISOString().split('T')[0];
                const isCurrentMonth = dateObj.getMonth() === month;

                const dayTasks = tasks.filter((t) => t.dueDate === dateStr);

                return (
                  <div
                    key={i}
                    onClick={() => handleAddNewRow('Do zrobienia', dateStr)}
                    className={`min-h-[70px] p-1.5 flex flex-col justify-between cursor-pointer transition-colors ${
                      isCurrentMonth
                        ? 'bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-850'
                        : 'bg-slate-50/50 dark:bg-slate-950/40 text-slate-400'
                    }`}
                  >
                    <div className="text-[10px] font-mono font-semibold text-slate-500">
                      {dateObj.getDate()}
                    </div>
                    <div className="space-y-1 overflow-hidden">
                      {dayTasks.slice(0, 2).map((t) => (
                        <div
                          key={t.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveRecord(t);
                          }}
                          className="px-1 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[9px] font-medium truncate"
                        >
                          {t.title}
                        </div>
                      ))}
                      {dayTasks.length > 2 && (
                        <span className="text-[9px] text-slate-400">+{dayTasks.length - 2} więcej</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* VIEW 4: LIST */}
        {viewMode === 'list' && (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 p-2">
            {filteredTasks.map((task) => (
              <div
                key={task.id}
                onClick={() => setActiveRecord(task)}
                className="p-3 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-850/50 rounded-xl cursor-pointer group transition-colors"
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleCompleted(task);
                    }}
                    className="cursor-pointer text-slate-400 hover:text-emerald-500"
                  >
                    {task.isCompleted ? (
                      <CheckCircle2 size={16} className="text-emerald-500 fill-emerald-500/20" />
                    ) : (
                      <Circle size={16} />
                    )}
                  </button>
                  <span
                    className={`font-medium text-xs ${
                      task.isCompleted
                        ? 'line-through text-slate-400'
                        : 'text-slate-900 dark:text-white'
                    }`}
                  >
                    {task.title}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs">
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300 font-mono">
                    #{task.tag}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">{task.dueDate}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteTask(task.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-600 p-1"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* VIEW 5: GALLERY */}
        {viewMode === 'gallery' && (
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 overflow-y-auto h-full">
            {filteredTasks.map((task) => (
              <div
                key={task.id}
                onClick={() => setActiveRecord(task)}
                className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 overflow-hidden shadow-2xs hover:shadow-md cursor-pointer transition-all group flex flex-col justify-between"
              >
                <div className="h-24 bg-gradient-to-r from-blue-500/10 via-indigo-500/10 to-purple-500/10 p-3 flex items-start justify-between">
                  <span className="px-2 py-0.5 rounded-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-xs text-[10px] font-semibold text-slate-700 dark:text-slate-300">
                    {task.status}
                  </span>
                  <span className="text-base">{task.priority === 'Krytyczny' ? '🔥' : '📄'}</span>
                </div>

                <div className="p-3.5 space-y-2 flex-1">
                  <h4 className="font-bold text-xs text-slate-900 dark:text-white line-clamp-2">
                    {task.title}
                  </h4>
                  {task.description && (
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                      {task.description}
                    </p>
                  )}
                </div>

                <div className="px-3.5 py-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>#{task.tag}</span>
                  <span>{task.dueDate}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 4. Record Detail Modal (Full properties editor) */}
      {activeRecord && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <span className="text-xs font-mono text-slate-400">Edycja rekordu bazy</span>
              <button
                onClick={() => setActiveRecord(null)}
                className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  Tytuł rekordu
                </label>
                <input
                  type="text"
                  value={activeRecord.title}
                  onChange={(e) => {
                    const title = e.target.value;
                    setActiveRecord((prev) => (prev ? { ...prev, title } : null));
                    updateTask(activeRecord.id, { title });
                  }}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    Status
                  </label>
                  <select
                    value={activeRecord.status}
                    onChange={(e) => {
                      const status = e.target.value as TaskStatus;
                      setActiveRecord((prev) => (prev ? { ...prev, status } : null));
                      updateTask(activeRecord.id, {
                        status,
                        isCompleted: status === 'Zrobione',
                      });
                    }}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none"
                  >
                    <option value="Do zrobienia">Do zrobienia</option>
                    <option value="W trakcie">W trakcie</option>
                    <option value="Zrobione">Zrobione</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    Priorytet
                  </label>
                  <select
                    value={activeRecord.priority}
                    onChange={(e) => {
                      const priority = e.target.value as Priority;
                      setActiveRecord((prev) => (prev ? { ...prev, priority } : null));
                      updateTask(activeRecord.id, { priority });
                    }}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none"
                  >
                    <option value="Niski">Niski</option>
                    <option value="Średni">Średni</option>
                    <option value="Wysoki">Wysoki</option>
                    <option value="Krytyczny">Krytyczny</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    Termin (Data)
                  </label>
                  <input
                    type="date"
                    value={activeRecord.dueDate}
                    onChange={(e) => {
                      const dueDate = e.target.value;
                      setActiveRecord((prev) => (prev ? { ...prev, dueDate } : null));
                      updateTask(activeRecord.id, { dueDate });
                    }}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    Szacowane godziny
                  </label>
                  <input
                    type="number"
                    value={activeRecord.estimatedHours || 0}
                    onChange={(e) => {
                      const estimatedHours = Number(e.target.value);
                      setActiveRecord((prev) => (prev ? { ...prev, estimatedHours } : null));
                      updateTask(activeRecord.id, { estimatedHours });
                    }}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  Powiązana strona (Relacja)
                </label>
                <select
                  value={activeRecord.relationPageId || ''}
                  onChange={(e) => {
                    const relationPageId = e.target.value;
                    const foundPage = pages.find((p) => p.id === relationPageId);
                    setActiveRecord((prev) =>
                      prev
                        ? {
                            ...prev,
                            relationPageId,
                            relationPageTitle: foundPage?.title || '',
                          }
                        : null
                    );
                    updateTask(activeRecord.id, {
                      relationPageId,
                      relationPageTitle: foundPage?.title || '',
                    });
                  }}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none"
                >
                  <option value="">Brak powiązania</option>
                  {pages
                    .filter((p) => !p.isDeleted)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.icon || '📄'} {p.title}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  Notatki / Opis rekordu
                </label>
                <textarea
                  rows={3}
                  value={activeRecord.description || ''}
                  onChange={(e) => {
                    const description = e.target.value;
                    setActiveRecord((prev) => (prev ? { ...prev, description } : null));
                    updateTask(activeRecord.id, { description });
                  }}
                  placeholder="Dodaj szczegóły lub notatki..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none resize-none"
                />
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => {
                  deleteTask(activeRecord.id);
                  setActiveRecord(null);
                }}
                className="px-3 py-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Usuń rekord
              </button>
              <button
                onClick={() => setActiveRecord(null)}
                className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-xl text-xs font-bold cursor-pointer"
              >
                Zamknij
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
