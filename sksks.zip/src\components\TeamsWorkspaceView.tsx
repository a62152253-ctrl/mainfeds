import React, { useState, useMemo, useEffect } from 'react';
import {
  Users,
  Mail,
  UserPlus,
  Check,
  X,
  Shield,
  Plus,
  Building2,
  AlertCircle,
  Copy,
  Settings,
  Trash2,
  Search,
  ExternalLink,
  ChevronDown,
  Info,
  Layers,
  Sparkles,
  LogOut,
  Calendar,
  Lock,
  FileText,
  CheckSquare,
  Pin,
  Megaphone,
  Activity,
  ArrowRight,
  Filter,
  CheckCircle2,
  Clock,
  Send,
  UserCheck,
  Share2,
  ListTodo,
  Tag,
  Star,
  Eye,
  Sliders,
  Flame,
  AlertTriangle,
  GripVertical,
  TrendingUp,
  Zap,
} from 'lucide-react';
import { useWorkspace } from '../context/WorkspaceContext';
import { useAuth } from '../context/AuthContext';
import { TeamRole, TaskStatus, Priority, TaskItem } from '../types/workspace';
import {
  triggerSendInviteEmail,
  buildTeamInviteJoinUrl,
} from '../features/team/teamEmailService';

const TEAM_ICONS = ['🏢', '🚀', '💻', '🎨', '📈', '⚡', '🎯', '🔬', '🌐', '🛡️', '⭐', '💡', '🔥', '📊', '💼'];

const ROLE_CONFIG: Record<
  TeamRole,
  { label: string; color: string; bg: string; border: string; desc: string }
> = {
  Owner: {
    label: 'Właściciel (Owner)',
    color: 'text-purple-700',
    bg: 'bg-purple-50',
    border: 'border-purple-200',
    desc: 'Pełna kontrola, usuwanie pokoju, zarządzanie uprawnieniami i rozliczeniami.',
  },
  Admin: {
    label: 'Administrator',
    color: 'text-blue-700',
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    desc: 'Zarządzanie członkami, wysyłanie zaproszeń, edycja współdzielonych dokumentów.',
  },
  Editor: {
    label: 'Edytor',
    color: 'text-emerald-700',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    desc: 'Tworzenie, edytowanie, komentowanie i eksport dokumentów w zespole.',
  },
  Viewer: {
    label: 'Przeglądający (Viewer)',
    color: 'text-slate-700',
    bg: 'bg-slate-100',
    border: 'border-slate-200',
    desc: 'Dostęp tylko do odczytu, przeglądanie baz danych i dodawanie komentarzy.',
  },
};

interface TeamAnnouncement {
  id: string;
  teamId: string;
  title: string;
  content: string;
  category: 'Ważne' | 'Sprint' | 'Spotkanie' | 'Informacja';
  authorName: string;
  authorEmail: string;
  pinned: boolean;
  createdAt: number;
  acknowledgments: string[];
}

export const TeamsWorkspaceView: React.FC = () => {
  const { user } = useAuth();
  const {
    currentWorkspace,
    workspaces,
    switchWorkspace,
    createTeamWorkspace,
    addTeamMemberDirectly,
    teamInvites,
    sendTeamInvite,
    respondToInvite,
    cancelTeamInvite,
    updateMemberRole,
    removeTeamMember,
    deleteTeamWorkspace,
    updateTeamSettings,
    pages,
    tasks,
    createPage,
    setActivePageId,
    setActiveView,
    addTask,
    updateTask,
    updateTaskStatus,
    addNotification,
  } = useWorkspace();

  const [dragOverMemberId, setDragOverMemberId] = useState<string | null>(null);
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);

  // Active Tab in Team Hub
  const [activeTab, setActiveTab] = useState<'members' | 'docs' | 'tasks' | 'announcements' | 'activity' | 'settings'>('members');

  // New Team Modal State
  const [isCreatingTeam, setIsCreatingTeam] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamIcon, setNewTeamIcon] = useState('🏢');
  const [newTeamDesc, setNewTeamDesc] = useState('');

  // Settings Modal State
  const [editingWorkspaceId, setEditingWorkspaceId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editIcon, setEditIcon] = useState('🏢');
  const [editDesc, setEditDesc] = useState('');

  // Invite Form State
  const [inviteMode, setInviteMode] = useState<'link' | 'direct'>('link');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<TeamRole>('Editor');
  const [directName, setDirectName] = useState('');
  const [directEmail, setDirectEmail] = useState('');
  const [directRole, setDirectRole] = useState<TeamRole>('Editor');

  // Filtering & Search
  const [memberSearch, setMemberSearch] = useState('');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<'All' | TeamRole>('All');
  const [docSearch, setDocSearch] = useState('');
  const [taskAssigneeFilter, setTaskAssigneeFilter] = useState<string>('all');
  const [activityCategoryFilter, setActivityCategoryFilter] = useState<'all' | 'doc' | 'task' | 'member' | 'announcement'>('all');

  // New Quick Task state in Tasks tab
  const [newQuickTaskTitle, setNewQuickTaskTitle] = useState('');
  const [newQuickTaskAssignee, setNewQuickTaskAssignee] = useState('');
  const [newQuickTaskPriority, setNewQuickTaskPriority] = useState<Priority>('Średni');

  // Announcements state (persisted per workspace)
  const [announcements, setAnnouncements] = useState<TeamAnnouncement[]>(() => {
    try {
      const saved = localStorage.getItem(`nowoczesne_team_announcements_${currentWorkspace.id}`);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [
      {
        id: 'ann-init-1',
        teamId: currentWorkspace.id,
        title: '🚀 Pokój pracy zespołu jest aktywny!',
        content: 'Wspólnie tworzymy, edytujemy notatki i delegujemy zadania. Sprawdź listę członków, dodaj dokument lub przypisz zadanie.',
        category: 'Ważne',
        authorName: 'Nowoczesne Studio',
        authorEmail: 'zespol@searchpoint.pl',
        pinned: true,
        createdAt: Date.now() - 3600000 * 12,
        acknowledgments: [],
      },
      {
        id: 'ann-init-2',
        teamId: currentWorkspace.id,
        title: '📌 Standardy nazewnictwa i tagi',
        content: 'Dodawajcie tagi (#PRODUKCJA, #FINANSE, #TECH, #DESIGN) do dokumentów, aby ułatwić wyszukiwanie globalne (Ctrl+K).',
        category: 'Informacja',
        authorName: 'Koordynator',
        authorEmail: 'admin@searchpoint.pl',
        pinned: false,
        createdAt: Date.now() - 3600000 * 3,
        acknowledgments: [],
      },
    ];
  });

  // New Announcement Form Modal
  const [showNewAnnModal, setShowNewAnnModal] = useState(false);
  const [newAnnTitle, setNewAnnTitle] = useState('');
  const [newAnnContent, setNewAnnContent] = useState('');
  const [newAnnCategory, setNewAnnCategory] = useState<'Ważne' | 'Sprint' | 'Spotkanie' | 'Informacja'>('Ważne');
  const [newAnnPinned, setNewAnnPinned] = useState(false);

  // UI Feedback Modals
  const [showRbacModal, setShowRbacModal] = useState(false);
  const [copiedLinkInviteId, setCopiedLinkInviteId] = useState<string | null>(null);
  const [copiedQuickLink, setCopiedQuickLink] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [memberToRemove, setMemberToRemove] = useState<{ userId: string; name: string } | null>(null);
  const [teamToDelete, setTeamToDelete] = useState<{ id: string; name: string } | null>(null);

  // Sync announcements to localStorage when modified
  useEffect(() => {
    try {
      localStorage.setItem(`nowoczesne_team_announcements_${currentWorkspace.id}`, JSON.stringify(announcements));
    } catch {
      // ignore
    }
  }, [announcements, currentWorkspace.id]);

  // Reload announcements when workspace switches
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`nowoczesne_team_announcements_${currentWorkspace.id}`);
      if (saved) {
        setAnnouncements(JSON.parse(saved));
      } else {
        setAnnouncements([
          {
            id: 'ann-init-1',
            teamId: currentWorkspace.id,
            title: `🚀 Witamy w pokoju: ${currentWorkspace.name}`,
            content: 'Rozpocznij współpracę z zespołem: dodawaj dokumenty, deleguj zadania i publikuj ogłoszenia.',
            category: 'Ważne',
            authorName: user?.displayName || 'Admin',
            authorEmail: user?.email || 'admin@searchpoint.pl',
            pinned: true,
            createdAt: Date.now() - 3600000 * 2,
            acknowledgments: [],
          },
        ]);
      }
    } catch {
      // ignore
    }
  }, [currentWorkspace.id]);

  // Incoming invites for current authenticated user
  const pendingInvitesForUser = teamInvites.filter(
    (inv) => inv.inviteeEmail.toLowerCase() === (user?.email || '').toLowerCase() && inv.status === 'pending'
  );

  // Outgoing pending invites for current active team workspace
  const outgoingInvitesForCurrentTeam = teamInvites.filter(
    (inv) => inv.teamId === currentWorkspace.id && inv.status === 'pending'
  );

  // Current user's role in the active team workspace
  const currentUserRoleInActiveTeam: TeamRole = useMemo(() => {
    if (currentWorkspace.id === 'ws-personal') return 'Owner';
    const member = currentWorkspace.members?.find((m) => m.userId === user?.uid || m.email === user?.email);
    return member?.role || 'Viewer';
  }, [currentWorkspace, user]);

  const canManageMembers =
    currentUserRoleInActiveTeam === 'Owner' ||
    currentUserRoleInActiveTeam === 'Admin' ||
    currentWorkspace.id === 'ws-personal';
  const isOwner = currentUserRoleInActiveTeam === 'Owner';

  const showStatus = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setStatusMessage({ text, type });
    setTimeout(() => setStatusMessage(null), 3500);
  };

  const handleCreateTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim()) return;
    const newId = await createTeamWorkspace(
      newTeamName.trim(),
      newTeamIcon,
      newTeamDesc.trim() || 'Współdzielony pokój pracy zespołu'
    );
    setNewTeamName('');
    setNewTeamDesc('');
    setIsCreatingTeam(false);
    if (newId) {
      showStatus('Pomyślnie utworzono nowy pokój pracy!');
    }
  };

  const handleOpenSettings = (ws: any) => {
    setEditingWorkspaceId(ws.id);
    setEditName(ws.name);
    setEditIcon(ws.icon || '🏢');
    setEditDesc(ws.description || '');
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWorkspaceId || !editName.trim()) return;
    await updateTeamSettings(editingWorkspaceId, {
      name: editName.trim(),
      icon: editIcon,
      description: editDesc.trim(),
    });
    setEditingWorkspaceId(null);
    showStatus('Zapisano ustawienia pokoju pracy.');
  };

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail.trim()) {
      showStatus('Podaj adres e-mail zapraszanej osoby.', 'error');
      return;
    }
    if (!/\S+@\S+\.\S+/.test(inviteEmail.trim())) {
      showStatus('Wprowadź prawidłowy adres e-mail.', 'error');
      return;
    }

    if (currentWorkspace.members?.some((m) => m.email.toLowerCase() === inviteEmail.trim().toLowerCase())) {
      showStatus('Ten użytkownik jest już członkiem tego zespołu.', 'info');
      return;
    }

    await sendTeamInvite(currentWorkspace.id, inviteEmail.trim(), inviteRole);
    setInviteEmail('');
    showStatus(`Wysłano zaproszenie z uprawnieniami ${inviteRole} do ${inviteEmail}! Link dołączenia skopiowano do schowka.`);
  };

  const handleDirectAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!directEmail.trim()) {
      showStatus('Wprowadź adres e-mail współpracownika.', 'error');
      return;
    }
    if (!/\S+@\S+\.\S+/.test(directEmail.trim())) {
      showStatus('Wprowadź prawidłowy adres e-mail.', 'error');
      return;
    }
    if (currentWorkspace.members?.some((m) => m.email.toLowerCase() === directEmail.trim().toLowerCase())) {
      showStatus('Ten użytkownik jest już członkiem tego zespołu.', 'info');
      return;
    }

    await addTeamMemberDirectly(
      currentWorkspace.id,
      directName.trim() || directEmail.split('@')[0],
      directEmail.trim(),
      directRole
    );
    setDirectName('');
    setDirectEmail('');
    showStatus(`Dodano ${directEmail} do zespołu z uprawnieniami ${directRole}!`);
  };

  // Auto-switch to first available team if on personal workspace
  useEffect(() => {
    if (currentWorkspace.id === 'ws-personal') {
      const firstTeam = workspaces.find((w) => w.id !== 'ws-personal');
      if (firstTeam) {
        switchWorkspace(firstTeam.id);
      }
    }
  }, [currentWorkspace.id, workspaces]);

  const handleCopyInviteLink = (inviteId: string) => {
    const inv = teamInvites.find((i) => i.id === inviteId);
    const inviteUrl = buildTeamInviteJoinUrl(
      inviteId,
      inv?.teamId || currentWorkspace.id,
      inv?.teamName || currentWorkspace.name,
      inv?.role || 'Editor'
    );
    navigator.clipboard.writeText(inviteUrl);
    setCopiedLinkInviteId(inviteId);
    showStatus('Skopiowano unikalny link zaproszenia do schowka!');
    setTimeout(() => setCopiedLinkInviteId(null), 2500);
  };

  const handleCopyTeamQuickLink = () => {
    const link = buildTeamInviteJoinUrl(
      `quick-${currentWorkspace.id}`,
      currentWorkspace.id,
      currentWorkspace.name,
      'Editor'
    );
    navigator.clipboard.writeText(link);
    setCopiedQuickLink(true);
    showStatus('Skopiowano uniwersalny link dołączenia do pokoju! Udostępnij go współpracownikom.');
    setTimeout(() => setCopiedQuickLink(false), 2500);
  };

  // Add announcement handler
  const handlePublishAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnnTitle.trim() || !newAnnContent.trim()) return;

    const newAnn: TeamAnnouncement = {
      id: `ann-${Date.now()}`,
      teamId: currentWorkspace.id,
      title: newAnnTitle.trim(),
      content: newAnnContent.trim(),
      category: newAnnCategory,
      authorName: user?.displayName || user?.email?.split('@')[0] || 'Członek zespołu',
      authorEmail: user?.email || '',
      pinned: newAnnPinned,
      createdAt: Date.now(),
      acknowledgments: user?.email ? [user.email] : [],
    };

    setAnnouncements((prev) => [newAnn, ...prev]);
    setNewAnnTitle('');
    setNewAnnContent('');
    setNewAnnPinned(false);
    setShowNewAnnModal(false);
    showStatus('Opublikowano nowe ogłoszenie w zespole!');
  };

  const handleToggleAcknowledge = (annId: string) => {
    if (!user?.email) return;
    setAnnouncements((prev) =>
      prev.map((a) => {
        if (a.id !== annId) return a;
        const exists = a.acknowledgments.includes(user.email!);
        return {
          ...a,
          acknowledgments: exists
            ? a.acknowledgments.filter((em) => em !== user.email)
            : [...a.acknowledgments, user.email!],
        };
      })
    );
  };

  const handleTogglePinAnnouncement = (annId: string) => {
    setAnnouncements((prev) =>
      prev.map((a) => (a.id === annId ? { ...a, pinned: !a.pinned } : a))
    );
  };

  const handleDeleteAnnouncement = (annId: string) => {
    setAnnouncements((prev) => prev.filter((a) => a.id !== annId));
    showStatus('Usunięto ogłoszenie.');
  };

  // Quick add task handler
  const handleCreateTeamTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuickTaskTitle.trim()) return;

    await addTask({
      title: newQuickTaskTitle.trim(),
      status: 'Do zrobienia',
      priority: newQuickTaskPriority,
      dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
      tag: 'ZESPÓŁ',
      assignee: newQuickTaskAssignee || user?.email || undefined,
    });

    setNewQuickTaskTitle('');
    showStatus('Dodano zadanie zespołowe!');
  };

  // Filtered members
  const filteredMembers = useMemo(() => {
    let list = currentWorkspace.members || [];
    if (selectedRoleFilter !== 'All') {
      list = list.filter((m) => m.role === selectedRoleFilter);
    }
    if (memberSearch.trim()) {
      const q = memberSearch.toLowerCase();
      list = list.filter(
        (m) => m.name.toLowerCase().includes(q) || m.email.toLowerCase().includes(q)
      );
    }
    return list;
  }, [currentWorkspace.members, selectedRoleFilter, memberSearch]);

  // Team pages
  const activeTeamPages = useMemo(() => {
    return pages.filter(
      (p) =>
        !p.isDeleted &&
        (p.workspaceId === currentWorkspace.id ||
          p.teamId === currentWorkspace.id ||
          (currentWorkspace.id === 'ws-personal' && !p.teamId))
    );
  }, [pages, currentWorkspace.id]);

  const filteredTeamPages = useMemo(() => {
    if (!docSearch.trim()) return activeTeamPages;
    const q = docSearch.toLowerCase();
    return activeTeamPages.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q)) ||
        p.blocks.some((b) => b.content?.toLowerCase().includes(q))
    );
  }, [activeTeamPages, docSearch]);

  // Team tasks
  const filteredTeamTasks = useMemo(() => {
    const list = tasks.filter(
      (t) =>
        t.workspaceId === currentWorkspace.id ||
        t.teamId === currentWorkspace.id ||
        currentWorkspace.id === 'ws-personal'
    );
    if (taskAssigneeFilter === 'all') return list;
    return list.filter((t) => t.assignee === taskAssigneeFilter);
  }, [tasks, currentWorkspace.id, taskAssigneeFilter]);

  // Drag & drop task reassignment handler
  const handleDropTaskOnMember = (e: React.DragEvent, targetMember: { email: string; name: string }) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain') || draggedTaskId;
    if (!taskId) return;
    const task = tasks.find((t) => t.id === taskId);
    if (!task) return;

    if (task.assignee === targetMember.email) {
      setDragOverMemberId(null);
      setDraggedTaskId(null);
      return;
    }

    updateTask(taskId, { assignee: targetMember.email });
    addNotification(
      'Reallokacja zadania',
      `Przeniesiono zadanie "${task.title}" do: ${targetMember.name || targetMember.email.split('@')[0]}`,
      'success'
    );
    setDraggedTaskId(null);
    setDragOverMemberId(null);
  };

  // Advanced Workload & Burnout calculation engine
  const memberWorkloadStats = useMemo(() => {
    if (!currentWorkspace?.members) return [];

    return currentWorkspace.members.map((m) => {
      const assignedTasks = tasks.filter((t) => t.assignee === m.email || t.assignee === m.name);
      const activeTasks = assignedTasks.filter((t) => t.status !== 'Zrobione');
      const completedTasks = assignedTasks.filter((t) => t.status === 'Zrobione');

      // Calculate weighted hours: Krytyczny=8h, Wysoki=5h, Średni=3h, Niski=2h
      const totalHours = activeTasks.reduce((sum, t) => {
        if (t.estimatedHours) return sum + t.estimatedHours;
        switch (t.priority) {
          case 'Krytyczny':
            return sum + 8;
          case 'Wysoki':
            return sum + 5;
          case 'Średni':
            return sum + 3;
          case 'Niski':
            return sum + 2;
          default:
            return sum + 3;
        }
      }, 0);

      // Baseline normal capacity: 20 hours
      const capacityBaseline = 20;
      const workloadRatio = Math.round((totalHours / capacityBaseline) * 100);

      const isBurnoutRisk = workloadRatio >= 120;
      const isHigh = workloadRatio >= 90 && workloadRatio < 120;
      const isOptimal = workloadRatio >= 50 && workloadRatio < 90;
      const isLow = workloadRatio < 50;

      return {
        member: m,
        assignedTasks,
        activeTasks,
        completedTasks,
        totalHours,
        workloadRatio,
        isBurnoutRisk,
        isHigh,
        isOptimal,
        isLow,
      };
    });
  }, [currentWorkspace?.members, tasks]);

  const overloadedCount = memberWorkloadStats.filter((s) => s.isBurnoutRisk).length;
  const highCount = memberWorkloadStats.filter((s) => s.isHigh).length;
  const optimalCount = memberWorkloadStats.filter((s) => s.isOptimal).length;
  const availableCount = memberWorkloadStats.filter((s) => s.isLow).length;

  // Dynamic Activity Feed synthesized from workspace
  const teamActivities = useMemo(() => {
    const list: {
      id: string;
      category: 'doc' | 'task' | 'member' | 'announcement';
      title: string;
      subtitle: string;
      author: string;
      time: number;
    }[] = [];

    // Pages activity
    activeTeamPages.forEach((p) => {
      list.push({
        id: `p-${p.id}`,
        category: 'doc',
        title: `Zaktualizowano stronę "${p.title || 'Bez tytułu'}"`,
        subtitle: p.tags.length > 0 ? `Tagi: #${p.tags.join(', #')}` : 'Dokument roboczy',
        author: p.authorName || 'Członek zespołu',
        time: p.updatedAt || p.createdAt,
      });

      // Contextual comments & @mentions activity
      (p.comments || []).forEach((c) => {
        list.push({
          id: `c-${c.id}`,
          category: 'doc',
          title: c.text.includes('@')
            ? `Wzmianka (@) w dyskusji do "${p.title || 'Dokument'}"`
            : `Komentarz pod sekcją w "${p.title || 'Dokument'}"`,
          subtitle: c.text.length > 80 ? c.text.slice(0, 80) + '...' : c.text,
          author: c.author,
          time: c.timestamp,
        });
      });
    });

    // Tasks activity
    tasks.forEach((t) => {
      list.push({
        id: `t-${t.id}`,
        category: 'task',
        title: `Zadanie: "${t.title}" (${t.status})`,
        subtitle: t.assignee ? `Przypisano do: ${t.assignee}` : 'Nieprzypisane',
        author: t.assignee || 'Zespół',
        time: t.updatedAt || t.createdAt || Date.now() - 3600000,
      });
    });

    // Members activity
    (currentWorkspace.members || []).forEach((m) => {
      list.push({
        id: `m-${m.userId}`,
        category: 'member',
        title: `Dołączono do pokoju jako ${m.role}`,
        subtitle: m.email,
        author: m.name || m.email,
        time: m.joinedAt || Date.now() - 86400000,
      });
    });

    // Announcements activity
    announcements.forEach((a) => {
      list.push({
        id: `a-${a.id}`,
        category: 'announcement',
        title: `Ogłoszenie: "${a.title}"`,
        subtitle: a.content.slice(0, 70) + '...',
        author: a.authorName,
        time: a.createdAt,
      });
    });

    return list
      .filter((item) => (activityCategoryFilter === 'all' ? true : item.category === activityCategoryFilter))
      .sort((a, b) => b.time - a.time)
      .slice(0, 30);
  }, [activeTeamPages, tasks, currentWorkspace.members, announcements, activityCategoryFilter]);

  return (
    <div className="flex-1 h-full overflow-y-auto bg-[#f8fafc] p-6 lg:p-10 space-y-6 text-slate-800 font-sans">
      {/* ========================================================================= */}
      {/* 1. TOP HEADER & BREADCRUMBS                                               */}
      {/* ========================================================================= */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-3">
            <span className="text-3xl p-2 rounded-2xl bg-white border border-slate-200 shadow-2xs">
              {currentWorkspace.icon || (currentWorkspace.id === 'ws-personal' ? '👤' : '🏢')}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl lg:text-2xl font-extrabold text-slate-900 tracking-tight">
                  {currentWorkspace.name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider">
                  {currentWorkspace.id === 'ws-personal' ? 'Prywatna' : 'Pokój Zespołu'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {currentWorkspace.description || 'Współdzielona przestrzeń współpracy, dokumentacji i zadań.'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto flex-wrap">
          {currentWorkspace.id !== 'ws-personal' && (
            <button
              onClick={handleCopyTeamQuickLink}
              className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-all"
              title="Kopiuj szybki link zaproszenia do pokoju"
            >
              {copiedQuickLink ? <Check size={14} className="text-emerald-600" /> : <Share2 size={14} className="text-emerald-600" />}
              <span>{copiedQuickLink ? 'Skopiowano link!' : 'Zaproś linkiem'}</span>
            </button>
          )}

          <button
            onClick={() => setShowRbacModal(true)}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
          >
            <Shield size={14} className="text-blue-600" />
            <span>Uprawnienia RBAC</span>
          </button>

          <button
            onClick={() => setIsCreatingTeam(true)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-sm hover:shadow transition-all"
          >
            <Plus size={15} />
            <span>Nowy zespół</span>
          </button>
        </div>
      </div>

      {/* Workspace Switcher Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0 mr-1">
          Przestrzenie:
        </span>
        {workspaces.map((ws) => {
          const isActive = ws.id === currentWorkspace.id;
          return (
            <button
              key={ws.id}
              onClick={() => switchWorkspace(ws.id)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all shrink-0 border ${
                isActive
                  ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              <span>{ws.icon || (ws.id === 'ws-personal' ? '👤' : '🏢')}</span>
              <span>{ws.name}</span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              )}
            </button>
          );
        })}
        <button
          onClick={() => setIsCreatingTeam(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all shrink-0 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200/80"
        >
          <Plus size={13} />
          <span>Nowy zespół</span>
        </button>
      </div>

      {/* Status Feedback Toast/Banner */}
      {statusMessage && (
        <div
          className={`p-3.5 rounded-2xl text-xs flex items-center justify-between border shadow-2xs transition-all animate-in fade-in ${
            statusMessage.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-800'
              : statusMessage.type === 'info'
              ? 'bg-blue-50 border-blue-200 text-blue-800'
              : 'bg-emerald-50 border-emerald-200 text-emerald-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMessage.type === 'error' ? (
              <AlertCircle size={15} className="text-rose-600" />
            ) : (
              <Check size={15} className="text-emerald-600" />
            )}
            <span className="font-medium">{statusMessage.text}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="text-xs opacity-60 hover:opacity-100 cursor-pointer">
            ✕
          </button>
        </div>
      )}

      {/* KPI Metric Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        <div className="p-4 bg-white border border-slate-200/90 rounded-2xl shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Przestrzenie</span>
            <Building2 size={15} className="text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{workspaces.length}</div>
          <div className="text-[10px] text-slate-400 mt-0.5">1 osobista · {workspaces.length - 1} zespołowych</div>
        </div>

        <div className="p-4 bg-white border border-slate-200/90 rounded-2xl shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Członkowie</span>
            <Users size={15} className="text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {currentWorkspace.members?.length || 1}
          </div>
          <div className="text-[10px] text-emerald-600 font-medium mt-0.5 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span>Wszyscy online</span>
          </div>
        </div>

        <div className="p-4 bg-white border border-slate-200/90 rounded-2xl shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Dokumenty</span>
            <FileText size={15} className="text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{activeTeamPages.length}</div>
          <div className="text-[10px] text-slate-400 mt-0.5">współdzielone strony</div>
        </div>

        <div className="p-4 bg-white border border-slate-200/90 rounded-2xl shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Otwarte zadania</span>
            <CheckSquare size={15} className="text-purple-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{tasks.filter((t) => t.status !== 'Zrobione').length}</div>
          <div className="text-[10px] text-slate-400 mt-0.5">{tasks.filter((t) => t.status === 'Zrobione').length} ukończonych</div>
        </div>

        <div className="p-4 bg-white border border-slate-200/90 rounded-2xl shadow-2xs col-span-2 md:col-span-1">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Twoja rola</span>
            <Shield size={15} className="text-indigo-500" />
          </div>
          <div className="text-lg font-bold text-slate-900 flex items-center gap-1.5">
            <span>{currentUserRoleInActiveTeam}</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {canManageMembers ? 'Pełne zarządzanie' : 'Dostęp roboczy'}
          </div>
        </div>
      </div>

      {/* Pending Incoming Invites For User */}
      {pendingInvitesForUser.length > 0 && (
        <div className="p-5 bg-gradient-to-r from-blue-50/90 via-indigo-50/80 to-purple-50/80 border border-blue-200/90 rounded-3xl space-y-3.5 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mail size={18} className="text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">
                Otrzymane zaproszenia do zespołów ({pendingInvitesForUser.length})
              </h3>
            </div>
            <span className="text-[11px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-semibold">
              Wymaga Twojej akcji
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingInvitesForUser.map((inv) => (
              <div
                key={inv.id}
                className="p-4 bg-white border border-blue-100 rounded-2xl flex items-center justify-between shadow-2xs"
              >
                <div>
                  <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <span>🏢</span>
                    <span>{inv.teamName}</span>
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Zapraszający: <span className="font-mono text-slate-700">{inv.inviterEmail}</span>
                  </p>
                  <div className="mt-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        ROLE_CONFIG[inv.role]?.bg || 'bg-slate-50'
                      } ${ROLE_CONFIG[inv.role]?.color || 'text-slate-700'} ${
                        ROLE_CONFIG[inv.role]?.border || 'border-slate-200'
                      }`}
                    >
                      Rola: {inv.role}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 ml-3">
                  <button
                    onClick={() => respondToInvite(inv.id, true)}
                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer shadow-2xs transition-all"
                  >
                    <Check size={13} />
                    <span>Dołącz</span>
                  </button>
                  <button
                    onClick={() => respondToInvite(inv.id, false)}
                    className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-xl cursor-pointer transition-colors"
                    title="Odrzuć zaproszenie"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. TEAM HUB CONTENT (TABS NAVIGATION)                                     */}
      {/* ========================================================================= */}
      {currentWorkspace.id !== 'ws-personal' ? (
        <div className="space-y-4">
          {/* Navigation Tab Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-200 no-scrollbar">
            <button
              onClick={() => setActiveTab('members')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === 'members'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <Users size={14} />
              <span>Członkowie ({currentWorkspace.members?.length || 1})</span>
            </button>

            <button
              onClick={() => setActiveTab('docs')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === 'docs'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <FileText size={14} />
              <span>Dokumenty ({activeTeamPages.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('tasks')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === 'tasks'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <CheckSquare size={14} />
              <span>Zadania & Workload ({tasks.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('announcements')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === 'announcements'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <Megaphone size={14} />
              <span>Ogłoszenia ({announcements.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('activity')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === 'activity'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <Activity size={14} />
              <span>Dziennik Aktywności</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === 'settings'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <Settings size={14} />
              <span>Ustawienia</span>
            </button>
          </div>

          {/* TAB 1: MEMBERS & RBAC */}
          {activeTab === 'members' && (
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 lg:p-8 space-y-6 shadow-xs">
              {/* Quick Universal Join Link Banner */}
              <div className="p-4 bg-gradient-to-r from-blue-50 via-indigo-50 to-slate-50 border border-blue-200/80 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold shrink-0 shadow-sm shadow-blue-500/20">
                    <Share2 size={18} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <span>Uniwersalny link dołączenia do pokoju</span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">1-kliknięcie</span>
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Każdy współpracownik, który otworzy ten link, natychmiast dołączy do Twojego zespołu!
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="font-mono text-[11px] bg-white px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 select-all truncate max-w-xs shadow-inner">
                    {buildTeamInviteJoinUrl(`quick-${currentWorkspace.id}`, currentWorkspace.id, currentWorkspace.name, 'Editor')}
                  </div>
                  <button
                    onClick={handleCopyTeamQuickLink}
                    className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-2xs hover:shadow transition-all shrink-0 flex items-center gap-1"
                  >
                    {copiedQuickLink ? <Check size={13} /> : <Copy size={13} />}
                    <span>{copiedQuickLink ? 'Skopiowano!' : 'Kopiuj link'}</span>
                  </button>
                </div>
              </div>

              {/* Member Addition & Invitation Hub (Dual Mode) */}
              {canManageMembers && (
                <div className="p-5 bg-slate-50/90 border border-slate-200 rounded-2xl space-y-4 shadow-2xs">
                  {/* Mode Tabs */}
                  <div className="flex items-center justify-between border-b border-slate-200/80 pb-3">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setInviteMode('link')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          inviteMode === 'link'
                            ? 'bg-blue-600 text-white shadow-2xs'
                            : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200/80'
                        }`}
                      >
                        <Mail size={13} />
                        <span>Zaproś linkiem lub e-mailem</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setInviteMode('direct')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          inviteMode === 'direct'
                            ? 'bg-blue-600 text-white shadow-2xs'
                            : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200/80'
                        }`}
                      >
                        <UserPlus size={13} />
                        <span>Dodaj członka natychmiast</span>
                      </button>
                    </div>

                    <span className="text-[11px] text-slate-400 hidden sm:inline">
                      {inviteMode === 'link'
                        ? 'Generuje unikalny token zaproszenia'
                        : 'Błyskawiczne dodanie do bazy współpracowników'}
                    </span>
                  </div>

                  {inviteMode === 'link' ? (
                    <form onSubmit={handleSendInvite} className="flex flex-col sm:flex-row items-center gap-2.5">
                      <div className="relative flex-1 w-full">
                        <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input
                          type="email"
                          required
                          value={inviteEmail}
                          onChange={(e) => setInviteEmail(e.target.value)}
                          placeholder="Wpisz adres e-mail współpracownika (np. kamil@firma.pl)..."
                          className="w-full pl-9 pr-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-2xs"
                        />
                      </div>

                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <select
                          value={inviteRole}
                          onChange={(e) => setInviteRole(e.target.value as TeamRole)}
                          className="px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 font-semibold focus:outline-none cursor-pointer shadow-2xs"
                        >
                          <option value="Admin">Administrator</option>
                          <option value="Editor">Edytor</option>
                          <option value="Viewer">Przeglądający (Viewer)</option>
                        </select>

                        <button
                          type="submit"
                          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs hover:shadow transition-all shrink-0"
                        >
                          <Send size={13} />
                          <span>Wyślij i kopiuj link</span>
                        </button>
                      </div>
                    </form>
                  ) : (
                    <form onSubmit={handleDirectAddMember} className="flex flex-col sm:flex-row items-center gap-2.5">
                      <div className="relative flex-1 w-full">
                        <UserCheck size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input
                          type="text"
                          value={directName}
                          onChange={(e) => setDirectName(e.target.value)}
                          placeholder="Imię i nazwisko (np. Anna Kowalska)..."
                          className="w-full pl-9 pr-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-2xs"
                        />
                      </div>

                      <div className="relative flex-1 w-full">
                        <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input
                          type="email"
                          required
                          value={directEmail}
                          onChange={(e) => setDirectEmail(e.target.value)}
                          placeholder="Adres e-mail (np. anna@searchpoint.pl)..."
                          className="w-full pl-9 pr-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-2xs"
                        />
                      </div>

                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <select
                          value={directRole}
                          onChange={(e) => setDirectRole(e.target.value as TeamRole)}
                          className="px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 font-semibold focus:outline-none cursor-pointer shadow-2xs"
                        >
                          <option value="Admin">Administrator</option>
                          <option value="Editor">Edytor</option>
                          <option value="Viewer">Przeglądający (Viewer)</option>
                        </select>

                        <button
                          type="submit"
                          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs hover:shadow transition-all shrink-0"
                        >
                          <Plus size={14} />
                          <span>Dodaj do zespołu</span>
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* Members Table */}
              <div className="space-y-3.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>Lista współpracowników ({filteredMembers.length})</span>
                  </h4>

                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={memberSearch}
                        onChange={(e) => setMemberSearch(e.target.value)}
                        placeholder="Szukaj członka..."
                        className="pl-7 pr-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 w-44"
                      />
                    </div>

                    <select
                      value={selectedRoleFilter}
                      onChange={(e) => setSelectedRoleFilter(e.target.value as any)}
                      className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 font-medium focus:outline-none cursor-pointer"
                    >
                      <option value="All">Wszystkie role</option>
                      <option value="Owner">Właściciele</option>
                      <option value="Admin">Administratorzy</option>
                      <option value="Editor">Edytorzy</option>
                      <option value="Viewer">Przeglądający</option>
                    </select>
                  </div>
                </div>

                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-400 font-semibold uppercase text-[10px]">
                      <tr>
                        <th className="px-4 py-3">Użytkownik</th>
                        <th className="px-4 py-3">Adres E-mail</th>
                        <th className="px-4 py-3">Rola (RBAC)</th>
                        <th className="px-4 py-3">Status</th>
                        {canManageMembers && <th className="px-4 py-3 text-right">Akcje</th>}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {filteredMembers.map((m, i) => {
                        const isSelf = m.userId === user?.uid || m.email === user?.email;
                        const isMemberOwner = m.role === 'Owner';

                        return (
                          <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-4 py-3 font-semibold text-slate-900 flex items-center gap-2.5">
                              <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-800 font-bold flex items-center justify-center text-[10px] shrink-0 border border-white shadow-2xs">
                                {(m.name || m.email)[0].toUpperCase()}
                              </div>
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span>{m.name || m.email.split('@')[0]}</span>
                                  {isSelf && (
                                    <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-mono font-normal">
                                      Ty
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-slate-400 font-normal">
                                  Dołączono: {m.joinedAt ? new Date(m.joinedAt).toLocaleDateString() : 'Brak danych'}
                                </span>
                              </div>
                            </td>

                            <td className="px-4 py-3 font-mono text-[11px] text-slate-500">{m.email}</td>

                            <td className="px-4 py-3">
                              {canManageMembers && !isMemberOwner && !isSelf ? (
                                <select
                                  value={m.role}
                                  onChange={(e) =>
                                    updateMemberRole(currentWorkspace.id, m.userId, e.target.value as TeamRole)
                                  }
                                  className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border cursor-pointer ${
                                    ROLE_CONFIG[m.role]?.bg || 'bg-slate-50'
                                  } ${ROLE_CONFIG[m.role]?.color || 'text-slate-700'} ${
                                    ROLE_CONFIG[m.role]?.border || 'border-slate-200'
                                  }`}
                                >
                                  <option value="Admin">Admin</option>
                                  <option value="Editor">Editor</option>
                                  <option value="Viewer">Viewer</option>
                                </select>
                              ) : (
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                    ROLE_CONFIG[m.role]?.bg || 'bg-slate-50'
                                  } ${ROLE_CONFIG[m.role]?.color || 'text-slate-700'} ${
                                    ROLE_CONFIG[m.role]?.border || 'border-slate-200'
                                  }`}
                                >
                                  {m.role}
                                </span>
                              )}
                            </td>

                            <td className="px-4 py-3 text-emerald-600 font-medium">
                              <span className="inline-flex items-center gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                                <span>Aktywny</span>
                              </span>
                            </td>

                            {canManageMembers && (
                              <td className="px-4 py-3 text-right">
                                {!isMemberOwner && !isSelf ? (
                                  <button
                                    onClick={() => setMemberToRemove({ userId: m.userId, name: m.name || m.email })}
                                    className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer transition-colors"
                                    title="Usuń członka z zespołu"
                                  >
                                    <Trash2 size={13} />
                                  </button>
                                ) : (
                                  <span className="text-[10px] text-slate-300">—</span>
                                )}
                              </td>
                            )}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Outgoing Invites */}
              {outgoingInvitesForCurrentTeam.length > 0 && (
                <div className="space-y-3 pt-4 border-t border-slate-100">
                  <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2">
                    <Mail size={14} className="text-indigo-600" />
                    <span>Oczekujące zaproszenia wysłane z tego pokoju ({outgoingInvitesForCurrentTeam.length})</span>
                  </h4>

                  <div className="overflow-x-auto rounded-2xl border border-slate-200">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-400 font-semibold uppercase text-[10px]">
                        <tr>
                          <th className="px-4 py-2.5">Adres e-mail</th>
                          <th className="px-4 py-2.5">Rola</th>
                          <th className="px-4 py-2.5">Zapraszający</th>
                          <th className="px-4 py-2.5 text-right">Akcje</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {outgoingInvitesForCurrentTeam.map((inv) => (
                          <tr key={inv.id} className="hover:bg-slate-50/50">
                            <td className="px-4 py-2.5 font-mono text-[11px] text-slate-900 font-semibold">
                              {inv.inviteeEmail}
                            </td>
                            <td className="px-4 py-2.5">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                  ROLE_CONFIG[inv.role]?.bg || 'bg-slate-50'
                                } ${ROLE_CONFIG[inv.role]?.color || 'text-slate-700'} ${
                                  ROLE_CONFIG[inv.role]?.border || 'border-slate-200'
                                }`}
                              >
                                {inv.role}
                              </span>
                            </td>
                            <td className="px-4 py-2.5 text-slate-500 font-mono text-[11px]">{inv.inviterEmail}</td>
                            <td className="px-4 py-2.5 text-right space-x-1.5 whitespace-nowrap">
                              <button
                                onClick={() => respondToInvite(inv.id, true)}
                                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-semibold cursor-pointer transition-colors inline-flex items-center gap-1 shadow-2xs"
                                title="Zatwierdź zaproszenie i dodaj członka natychmiast"
                              >
                                <UserCheck size={11} />
                                <span>Dołącz / Zatwierdź</span>
                              </button>
                              <button
                                onClick={() =>
                                  triggerSendInviteEmail({
                                    email: inv.inviteeEmail,
                                    teamName: currentWorkspace.name,
                                    inviterName: user?.displayName || user?.email || 'Współpracownik',
                                    inviteId: inv.id,
                                    teamId: inv.teamId,
                                    role: inv.role,
                                  })
                                }
                                className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-[10px] font-semibold cursor-pointer transition-colors inline-flex items-center gap-1 shadow-2xs"
                                title="Otwórz klienta poczty i wyślij e-mail z zaproszeniem"
                              >
                                <Mail size={11} />
                                <span>Wyślij e-mail</span>
                              </button>
                              <button
                                onClick={() => handleCopyInviteLink(inv.id)}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-semibold cursor-pointer transition-colors"
                              >
                                {copiedLinkInviteId === inv.id ? 'Skopiowano ✓' : 'Kopiuj link'}
                              </button>
                              {canManageMembers && (
                                <button
                                  onClick={() => cancelTeamInvite(inv.id)}
                                  className="px-2.5 py-1 hover:bg-rose-50 text-rose-600 rounded-lg text-[10px] font-semibold cursor-pointer transition-colors"
                                >
                                  Wycofaj
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: TEAM DOCUMENTS */}
          {activeTab === 'docs' && (
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 lg:p-8 space-y-6 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <FileText size={18} className="text-blue-600" />
                    <span>Dokumenty współdzielone w zespole ({filteredTeamPages.length})</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Wszyscy członkowie z uprawnieniami edytora mogą wspólnie pisać i modyfikować te treści.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={docSearch}
                      onChange={(e) => setDocSearch(e.target.value)}
                      placeholder="Szukaj w dokumentach..."
                      className="pl-7 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 w-48"
                    />
                  </div>

                  <button
                    onClick={async () => {
                      const newId = await createPage(undefined, 'Nowa notatka zespołowa');
                      if (newId) {
                        setActivePageId(newId);
                        setActiveView('doc');
                      }
                    }}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors shrink-0"
                  >
                    <Plus size={14} />
                    <span>Nowy dokument</span>
                  </button>
                </div>
              </div>

              {filteredTeamPages.length === 0 ? (
                <div className="text-center py-12 bg-slate-50/70 border border-dashed border-slate-200 rounded-2xl space-y-3">
                  <FileText size={28} className="mx-auto text-slate-300" />
                  <p className="text-xs text-slate-500">Brak dokumentów pasujących do kryteriów wyszukiwania.</p>
                  <button
                    onClick={async () => {
                      const newId = await createPage(undefined, 'Nowy dokument');
                      if (newId) {
                        setActivePageId(newId);
                        setActiveView('doc');
                      }
                    }}
                    className="px-4 py-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    + Utwórz pierwszy dokument
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {filteredTeamPages.map((page) => {
                    const firstContent = page.blocks?.find((b) => b.content && b.content.trim().length > 0)?.content?.trim();
                    const snippet = firstContent ? (firstContent.length > 70 ? firstContent.slice(0, 70) + '...' : firstContent) : 'Brak treści';

                    return (
                      <div
                        key={page.id}
                        onClick={() => {
                          setActivePageId(page.id);
                          setActiveView('doc');
                        }}
                        className="p-4 bg-white hover:bg-slate-50/80 border border-slate-200 rounded-2xl shadow-2xs hover:shadow-sm hover:border-blue-300 transition-all cursor-pointer flex flex-col justify-between group"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-2xl">{page.icon || '📄'}</span>
                            <span className="text-[10px] font-mono text-slate-400">
                              {new Date(page.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                            </span>
                          </div>

                          <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1">
                            {page.title || 'Bez tytułu'}
                          </h4>

                          <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                            {snippet}
                          </p>
                        </div>

                        <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                          <span className="flex items-center gap-1 text-slate-600 font-medium truncate">
                            <span>✍️</span>
                            <span className="truncate">{page.authorName || 'Autor'}</span>
                          </span>

                          <span className="text-blue-600 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                            <span>Otwórz</span>
                            <ArrowRight size={10} />
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: TASKS & WORKLOAD */}
          {activeTab === 'tasks' && (
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 lg:p-8 space-y-6 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <CheckSquare size={18} className="text-blue-600" />
                    <span>Zadania i Zarządzanie Obciążeniem (Workload & Burnout)</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Automatyczny kalkulator przepracowania (120%+) z ostrzeżeniami o ryzyku wypalenia oraz reallokacją zadań Drag & Drop.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-medium text-slate-400 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 flex items-center gap-1.5">
                    <Zap size={13} className="text-amber-500" />
                    <span>Norma: 20h / sprint</span>
                  </span>
                </div>
              </div>

              {/* Workload & Burnout KPI Summary Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className={`p-3.5 rounded-2xl border transition-all ${
                  overloadedCount > 0
                    ? 'bg-rose-50 border-rose-300 ring-1 ring-rose-300 shadow-xs'
                    : 'bg-slate-50/70 border-slate-200'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
                      <Flame size={14} className={overloadedCount > 0 ? 'text-rose-600 animate-bounce' : 'text-slate-400'} />
                      <span>Ryzyko wypalenia (&gt;120%)</span>
                    </span>
                    <span className={`text-base font-extrabold font-mono ${overloadedCount > 0 ? 'text-rose-600' : 'text-slate-700'}`}>
                      {overloadedCount}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Przeciążeni pracownicy</p>
                </div>

                <div className="p-3.5 rounded-2xl border bg-slate-50/70 border-slate-200">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
                      <AlertTriangle size={14} className="text-amber-500" />
                      <span>Wysokie (90-119%)</span>
                    </span>
                    <span className="text-base font-extrabold text-amber-600 font-mono">
                      {highCount}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Blisko limitu pojemności</p>
                </div>

                <div className="p-3.5 rounded-2xl border bg-slate-50/70 border-slate-200">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
                      <CheckCircle2 size={14} className="text-emerald-500" />
                      <span>W normie (50-89%)</span>
                    </span>
                    <span className="text-base font-extrabold text-emerald-600 font-mono">
                      {optimalCount}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Zrównoważony workload</p>
                </div>

                <div className="p-3.5 rounded-2xl border bg-slate-50/70 border-slate-200">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
                      <Zap size={14} className="text-blue-500" />
                      <span>Wolne moce (&lt;50%)</span>
                    </span>
                    <span className="text-base font-extrabold text-blue-600 font-mono">
                      {availableCount}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Gotowi na nowe zadania</p>
                </div>
              </div>

              {/* Burnout Prevention Smart Alert Banner */}
              {overloadedCount > 0 ? (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 animate-in fade-in">
                  <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                    <Flame size={16} className="animate-pulse" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-rose-900">
                      🚨 Wykryto ryzyko wypalenia zawodowego (Burnout Alert)!
                    </h4>
                    <p className="text-[11px] text-rose-700 mt-0.5 leading-relaxed">
                      W zespole występuje {overloadedCount} {overloadedCount === 1 ? 'osoba z obciążeniem' : 'osoby z obciążeniem'} powyżej 120% normy. Skorzystaj z funkcji <strong>Drag & Drop</strong>: przeciągnij zadania z kart przeciążonych osób na pracowników z dostępnymi wolnymi mocami (&lt;50%), aby zrównoważyć sprint.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-3.5 bg-emerald-50/80 border border-emerald-200 rounded-2xl flex items-center gap-3">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <CheckCircle2 size={15} />
                  </div>
                  <div className="text-xs text-emerald-800">
                    <strong>Workload zespołu zrównoważony.</strong> Wszyscy pracownicy mają obciążenie w bezpiecznym zakresie bez ryzyka przeciążenia.
                  </div>
                </div>
              )}

              {/* Interactive Member Workload & Drag & Drop Cards */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                  <span>Karty obciążenia pracowników (Upuść zadanie, aby natychmiast przypisać):</span>
                  {taskAssigneeFilter !== 'all' && (
                    <button
                      onClick={() => setTaskAssigneeFilter('all')}
                      className="text-blue-600 hover:underline text-[11px] font-semibold"
                    >
                      Pokaż wszystkich
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5">
                  {memberWorkloadStats.map((stat) => {
                    const m = stat.member;
                    const isSelected = taskAssigneeFilter === m.email || taskAssigneeFilter === m.name;
                    const isDragOver = dragOverMemberId === m.userId;

                    return (
                      <div
                        key={m.userId}
                        onDragOver={(e) => {
                          e.preventDefault();
                          setDragOverMemberId(m.userId);
                        }}
                        onDragLeave={() => setDragOverMemberId(null)}
                        onDrop={(e) => handleDropTaskOnMember(e, m)}
                        onClick={() => setTaskAssigneeFilter(isSelected ? 'all' : m.email)}
                        className={`p-4 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between ${
                          isDragOver
                            ? 'bg-blue-100/90 border-blue-500 ring-4 ring-blue-500/20 scale-[1.02] shadow-md'
                            : stat.isBurnoutRisk
                            ? 'bg-rose-50/60 border-rose-300 ring-1 ring-rose-200/80 shadow-xs hover:border-rose-400'
                            : stat.isHigh
                            ? 'bg-amber-50/50 border-amber-300 hover:border-amber-400 shadow-2xs'
                            : isSelected
                            ? 'bg-blue-50/80 border-blue-400 ring-2 ring-blue-400/20 shadow-xs'
                            : 'bg-slate-50/70 border-slate-200 hover:bg-slate-100/70'
                        }`}
                      >
                        <div>
                          {/* Card Header */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-8 h-8 rounded-full text-white font-bold flex items-center justify-center text-xs shadow-2xs ${
                                  stat.isBurnoutRisk
                                    ? 'bg-rose-600'
                                    : stat.isHigh
                                    ? 'bg-amber-600'
                                    : 'bg-blue-600'
                                }`}
                              >
                                {(m.name || m.email)[0].toUpperCase()}
                              </div>
                              <div>
                                <div className="font-bold text-xs text-slate-900 leading-tight truncate">
                                  {m.name || m.email.split('@')[0]}
                                </div>
                                <span className="text-[10px] text-slate-400 block truncate">{m.role}</span>
                              </div>
                            </div>

                            {/* Workload Status Pill */}
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 ${
                                stat.isBurnoutRisk
                                  ? 'bg-rose-100 text-rose-800 border-rose-300 animate-pulse'
                                  : stat.isHigh
                                  ? 'bg-amber-100 text-amber-800 border-amber-300'
                                  : stat.isOptimal
                                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                  : 'bg-blue-100 text-blue-800 border-blue-300'
                              }`}
                            >
                              {stat.isBurnoutRisk && <Flame size={10} />}
                              <span>{stat.workloadRatio}%</span>
                            </span>
                          </div>

                          {/* Workload Metric Details */}
                          <div className="mt-3 flex items-center justify-between text-[11px] text-slate-600 font-medium">
                            <span>W toku: <strong>{stat.activeTasks.length}</strong></span>
                            <span>Czas: <strong className="font-mono">{stat.totalHours}h</strong> / 20h</span>
                          </div>

                          {/* Progress Meter */}
                          <div className="mt-1.5">
                            <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all duration-300 ${
                                  stat.isBurnoutRisk
                                    ? 'bg-rose-600'
                                    : stat.isHigh
                                    ? 'bg-amber-500'
                                    : stat.isOptimal
                                    ? 'bg-emerald-500'
                                    : 'bg-blue-500'
                                }`}
                                style={{ width: `${Math.min(stat.workloadRatio, 100)}%` }}
                              />
                            </div>
                          </div>

                          {/* Active Tasks Draggable Preview Tray */}
                          {stat.activeTasks.length > 0 && (
                            <div className="mt-3 pt-2.5 border-t border-slate-200/70 space-y-1">
                              <span className="text-[9px] uppercase font-bold text-slate-400 block">
                                Zadania w toku (Przeciągnij stąd):
                              </span>
                              <div className="space-y-1 max-h-24 overflow-y-auto">
                                {stat.activeTasks.slice(0, 3).map((t) => (
                                  <div
                                    key={t.id}
                                    draggable={true}
                                    onDragStart={(e) => {
                                      e.stopPropagation();
                                      e.dataTransfer.setData('text/plain', t.id);
                                      setDraggedTaskId(t.id);
                                    }}
                                    onClick={(e) => e.stopPropagation()}
                                    className="p-1 px-1.5 bg-white border border-slate-200 rounded-lg text-[10px] text-slate-800 flex items-center justify-between cursor-grab active:cursor-grabbing hover:border-blue-300 shadow-2xs group/chip transition-all"
                                    title="Chwyć to zadanie i upuść na innego pracownika"
                                  >
                                    <div className="flex items-center gap-1 truncate min-w-0">
                                      <GripVertical size={10} className="text-slate-300 group-hover/chip:text-blue-500 shrink-0" />
                                      <span className="truncate font-medium">{t.title}</span>
                                    </div>
                                    <span className="text-[9px] font-bold text-slate-400 font-mono ml-1 shrink-0">
                                      {t.priority === 'Krytyczny' ? '8h' : t.priority === 'Wysoki' ? '5h' : '3h'}
                                    </span>
                                  </div>
                                ))}
                                {stat.activeTasks.length > 3 && (
                                  <span className="text-[10px] text-slate-400 block text-center">
                                    +{stat.activeTasks.length - 3} więcej...
                                  </span>
                                )}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Drop Target Guide Indicator */}
                        {isDragOver ? (
                          <div className="mt-3 p-2 bg-blue-200/80 border border-blue-400 rounded-xl text-center text-xs font-bold text-blue-900 animate-pulse">
                            🎯 Upuść tutaj, aby przypisać!
                          </div>
                        ) : (
                          <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                            <span>Zrobione: {stat.completedTasks.length}</span>
                            <span className="text-[9px] text-slate-400">Strefa Drag&amp;Drop</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Quick Add Task Form */}
              <form onSubmit={handleCreateTeamTask} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Plus size={14} className="text-blue-600" />
                  <span>Szybkie dodawanie zadania dla zespołu</span>
                </span>

                <div className="flex flex-col sm:flex-row items-center gap-2">
                  <input
                    type="text"
                    required
                    value={newQuickTaskTitle}
                    onChange={(e) => setNewQuickTaskTitle(e.target.value)}
                    placeholder="Wpisz treść zadania zespołowego..."
                    className="flex-1 w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500 shadow-2xs"
                  />

                  <select
                    value={newQuickTaskAssignee}
                    onChange={(e) => setNewQuickTaskAssignee(e.target.value)}
                    className="w-full sm:w-44 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 font-medium focus:outline-none cursor-pointer shadow-2xs"
                  >
                    <option value="">Przypisz do...</option>
                    {currentWorkspace.members?.map((m) => (
                      <option key={m.userId} value={m.email}>
                        {m.name || m.email.split('@')[0]} ({m.role})
                      </option>
                    ))}
                  </select>

                  <select
                    value={newQuickTaskPriority}
                    onChange={(e) => setNewQuickTaskPriority(e.target.value as Priority)}
                    className="w-full sm:w-32 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 font-medium focus:outline-none cursor-pointer shadow-2xs"
                  >
                    <option value="Niski">Niski (2h)</option>
                    <option value="Średni">Średni (3h)</option>
                    <option value="Wysoki">Wysoki (5h)</option>
                    <option value="Krytyczny">Krytyczny (8h)</option>
                  </select>

                  <button
                    type="submit"
                    className="w-full sm:w-auto px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-2xs transition-colors shrink-0"
                  >
                    Dodaj zadanie
                  </button>
                </div>
              </form>

              {/* Tasks List Table */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2">
                    <span>Lista zadań ({filteredTeamTasks.length})</span>
                    {taskAssigneeFilter !== 'all' && (
                      <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 text-[10px] font-semibold border border-blue-200">
                        Filtr: {taskAssigneeFilter}
                        <button onClick={() => setTaskAssigneeFilter('all')} className="ml-1 hover:text-blue-800">✕</button>
                      </span>
                    )}
                  </h4>

                  <button
                    onClick={() => setActiveView('kanban')}
                    className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <span>Otwórz Tablicę Kanban</span>
                    <ArrowRight size={12} />
                  </button>
                </div>

                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-400 font-semibold uppercase text-[10px]">
                      <tr>
                        <th className="px-4 py-3 w-8"></th>
                        <th className="px-4 py-3">Zadanie</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3">Przypisana osoba</th>
                        <th className="px-4 py-3">Priorytet (Obciążenie)</th>
                        <th className="px-4 py-3 text-right">Termin</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {filteredTeamTasks.map((t) => (
                        <tr
                          key={t.id}
                          draggable={true}
                          onDragStart={(e) => {
                            e.dataTransfer.setData('text/plain', t.id);
                            setDraggedTaskId(t.id);
                          }}
                          className="hover:bg-blue-50/40 transition-colors group cursor-grab active:cursor-grabbing"
                        >
                          <td className="px-3 py-3 text-slate-300 group-hover:text-blue-500">
                            <div title="Przeciągnij i upuść na kartę pracownika powyżej">
                              <GripVertical size={14} />
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2.5">
                              <input
                                type="checkbox"
                                checked={t.status === 'Zrobione'}
                                onChange={() =>
                                  updateTaskStatus(t.id, t.status === 'Zrobione' ? 'Do zrobienia' : 'Zrobione')
                                }
                                className="w-4 h-4 rounded accent-blue-600 cursor-pointer shrink-0"
                              />
                              <span className={`font-semibold ${t.status === 'Zrobione' ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                                {t.title}
                              </span>
                            </div>
                          </td>

                          <td className="px-4 py-3">
                            <select
                              value={t.status}
                              onChange={(e) => updateTaskStatus(t.id, e.target.value as TaskStatus)}
                              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border cursor-pointer ${
                                t.status === 'Zrobione'
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                  : t.status === 'W trakcie'
                                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                                  : 'bg-slate-100 text-slate-700 border-slate-200'
                              }`}
                            >
                              <option value="Do zrobienia">Do zrobienia</option>
                              <option value="W trakcie">W trakcie</option>
                              <option value="Zrobione">Zrobione</option>
                            </select>
                          </td>

                          <td className="px-4 py-3">
                            <select
                              value={t.assignee || ''}
                              onChange={(e) => updateTask(t.id, { assignee: e.target.value || undefined })}
                              className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-[11px] font-medium text-slate-700 cursor-pointer shadow-2xs"
                            >
                              <option value="">Nieprzypisane</option>
                              {currentWorkspace.members?.map((m) => (
                                <option key={m.userId} value={m.email}>
                                  {m.name || m.email.split('@')[0]}
                                </option>
                              ))}
                            </select>
                          </td>

                          <td className="px-4 py-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                t.priority === 'Krytyczny'
                                  ? 'bg-rose-50 text-rose-700 border-rose-200'
                                  : t.priority === 'Wysoki'
                                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                                  : 'bg-slate-100 text-slate-600 border-slate-200'
                              }`}
                            >
                              {t.priority} ({t.priority === 'Krytyczny' ? '8h' : t.priority === 'Wysoki' ? '5h' : t.priority === 'Średni' ? '3h' : '2h'})
                            </span>
                          </td>

                          <td className="px-4 py-3 text-right font-mono text-[11px] text-slate-500">
                            {t.dueDate || 'Brak'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ANNOUNCEMENTS & TEAM CHAT */}
          {activeTab === 'announcements' && (
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 lg:p-8 space-y-6 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Megaphone size={18} className="text-blue-600" />
                    <span>Tablica Ogłoszeń Zespołu</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Ważne komunikaty, wytyczne, terminy sprintów i informacje dla wszystkich współpracowników.
                  </p>
                </div>

                <button
                  onClick={() => setShowNewAnnModal(true)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-all shrink-0"
                >
                  <Plus size={14} />
                  <span>Nowe ogłoszenie</span>
                </button>
              </div>

              {/* Announcements Feed */}
              <div className="space-y-3.5">
                {announcements.map((ann) => {
                  const isAcknowledged = user?.email && ann.acknowledgments.includes(user.email);

                  return (
                    <div
                      key={ann.id}
                      className={`p-5 rounded-2xl border transition-all ${
                        ann.pinned
                          ? 'bg-amber-50/40 border-amber-200/80 shadow-xs ring-1 ring-amber-300/30'
                          : 'bg-white border-slate-200/90 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2">
                          {ann.pinned && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-1">
                              <Pin size={10} />
                              <span>Przypięte</span>
                            </span>
                          )}
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              ann.category === 'Ważne'
                                ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                : ann.category === 'Sprint'
                                ? 'bg-purple-50 text-purple-700 border border-purple-200'
                                : 'bg-blue-50 text-blue-700 border border-blue-200'
                            }`}
                          >
                            {ann.category}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">
                            {new Date(ann.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleTogglePinAnnouncement(ann.id)}
                            className={`p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 cursor-pointer transition-colors ${
                              ann.pinned ? 'text-amber-600' : ''
                            }`}
                            title={ann.pinned ? 'Odepnij ogłoszenie' : 'Przypnij na górze'}
                          >
                            <Pin size={13} />
                          </button>
                          {canManageMembers && (
                            <button
                              onClick={() => handleDeleteAnnouncement(ann.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer transition-colors"
                              title="Usuń ogłoszenie"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}
                        </div>
                      </div>

                      <h4 className="text-sm font-bold text-slate-900 mt-2">{ann.title}</h4>
                      <p className="text-xs text-slate-600 mt-1.5 leading-relaxed whitespace-pre-wrap">
                        {ann.content}
                      </p>

                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium">
                          <div className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-[10px]">
                            {ann.authorName[0]?.toUpperCase() || 'A'}
                          </div>
                          <span>{ann.authorName}</span>
                          <span className="text-slate-400 font-mono text-[10px]">({ann.authorEmail})</span>
                        </div>

                        <button
                          onClick={() => handleToggleAcknowledge(ann.id)}
                          className={`px-3 py-1 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all ${
                            isAcknowledged
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                          }`}
                        >
                          <CheckCircle2 size={13} className={isAcknowledged ? 'text-emerald-600' : 'text-slate-400'} />
                          <span>{isAcknowledged ? 'Przeczytano ✓' : 'Potwierdź przeczytanie'}</span>
                          {ann.acknowledgments.length > 0 && (
                            <span className="ml-1 text-[10px] font-mono opacity-80">({ann.acknowledgments.length})</span>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: TEAM AUDIT LOG & ACTIVITY */}
          {activeTab === 'activity' && (
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 lg:p-8 space-y-6 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Activity size={18} className="text-blue-600" />
                    <span>Dziennik Aktywności Zespołu (Live Audit Log)</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Historia wszystkich akcji, zmian w dokumentach, aktualizacji zadań i zdarzeń w tym pokoju.
                  </p>
                </div>

                <div className="flex items-center gap-1.5">
                  {(['all', 'doc', 'task', 'member', 'announcement'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActivityCategoryFilter(cat)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                        activityCategoryFilter === cat
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      {cat === 'all'
                        ? 'Wszystko'
                        : cat === 'doc'
                        ? 'Dokumenty'
                        : cat === 'task'
                        ? 'Zadania'
                        : cat === 'member'
                        ? 'Członkowie'
                        : 'Ogłoszenia'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="relative pl-6 space-y-4 border-l-2 border-slate-200 ml-3">
                {teamActivities.map((act) => (
                  <div key={act.id} className="relative group">
                    <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-white border-2 border-blue-500" />
                    <div className="p-3.5 bg-slate-50/70 border border-slate-200/80 rounded-2xl flex items-start justify-between gap-3 hover:bg-slate-100/70 transition-colors">
                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${
                              act.category === 'doc'
                                ? 'bg-amber-100 text-amber-800'
                                : act.category === 'task'
                                ? 'bg-purple-100 text-purple-800'
                                : act.category === 'member'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {act.category}
                          </span>
                          <span className="font-semibold text-xs text-slate-900">{act.title}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">{act.subtitle}</p>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-[10px] font-mono text-slate-400 block">
                          {new Date(act.time).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <span className="text-[10px] font-semibold text-slate-600 block mt-0.5">
                          {act.author}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: SETTINGS & DANGER ZONE */}
          {activeTab === 'settings' && (
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 lg:p-8 space-y-7 shadow-xs">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Settings size={18} className="text-blue-600" />
                  <span>Ustawienia i Bezpieczeństwo Pokoju</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Zarządzaj konfiguracją, tożsamością pokoju i uprawnieniami RBAC.
                </p>
              </div>

              {/* Room details card */}
              <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <span className="text-3xl p-2.5 bg-white border border-slate-200 rounded-2xl shadow-2xs">
                    {currentWorkspace.icon || '🏢'}
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{currentWorkspace.name}</h4>
                    <p className="text-xs text-slate-500 mt-0.5">{currentWorkspace.description}</p>
                    <span className="text-[10px] font-mono text-slate-400 mt-1 block">ID: {currentWorkspace.id}</span>
                  </div>
                </div>

                {isOwner && (
                  <button
                    onClick={() => handleOpenSettings(currentWorkspace)}
                    className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer shadow-2xs transition-colors shrink-0"
                  >
                    Edytuj dane
                  </button>
                )}
              </div>

              {/* Danger Zone */}
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <h4 className="text-xs font-bold text-rose-700 uppercase tracking-wider">Strefa Niebezpieczna</h4>
                <div className="p-4 bg-rose-50/50 border border-rose-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      {isOwner ? 'Usuń cały pokój zespołu' : 'Opuść ten zespół'}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {isOwner
                        ? 'Wszystkie dane, współdzielone dokumenty i zadania zostaną bezpowrotnie usunięte.'
                        : 'Utracisz natychmiast dostęp do zasobów i dokumentów tego pokoju.'}
                    </span>
                  </div>

                  {isOwner ? (
                    <button
                      onClick={() => setTeamToDelete({ id: currentWorkspace.id, name: currentWorkspace.name })}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-2xs transition-colors shrink-0"
                    >
                      Usuń zespół
                    </button>
                  ) : (
                    <button
                      onClick={() =>
                        setMemberToRemove({
                          userId: user?.uid || '',
                          name: user?.displayName || 'Ciebie',
                        })
                      }
                      className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-2xs transition-colors shrink-0"
                    >
                      Opuść zespół
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* PERSONAL WORKSPACE VIEW (Showcase all teams or Onboarding) */
        <div className="space-y-6">
          {/* Quick Invite & Create Hero Card */}
          <div className="p-6 lg:p-8 bg-gradient-to-r from-blue-50/90 via-indigo-50/70 to-purple-50/70 border border-blue-200/90 rounded-3xl space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="text-3xl p-2 bg-white rounded-2xl shadow-2xs">🚀</span>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Rozpocznij pracę zespołową
                  </h3>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Wpisz adres e-mail współpracownika – automatycznie utworzymy przestrzeń i wyślemy zaproszenie.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsCreatingTeam(true)}
                className="px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors shrink-0"
              >
                <Plus size={14} className="text-blue-600" />
                <span>Utwórz ręcznie zespół</span>
              </button>
            </div>

            <form onSubmit={handleSendInvite} className="flex flex-col sm:flex-row items-center gap-2.5 pt-2">
              <div className="relative flex-1 w-full">
                <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="Wpisz e-mail współpracownika (np. jan@firma.pl)..."
                  className="w-full pl-9 pr-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-2xs font-medium"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <select
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as TeamRole)}
                  className="px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 font-semibold focus:outline-none cursor-pointer shadow-2xs"
                >
                  <option value="Editor">Edytor</option>
                  <option value="Admin">Administrator</option>
                  <option value="Viewer">Przeglądający</option>
                </select>

                <button
                  type="submit"
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs hover:shadow transition-all shrink-0"
                >
                  <UserPlus size={14} />
                  <span>Wyślij zaproszenie</span>
                </button>
              </div>
            </form>
          </div>

          <div className="bg-white border border-slate-200 rounded-3xl p-6 lg:p-8 space-y-6 shadow-xs">
            <div className="flex items-center gap-3.5 pb-4 border-b border-slate-100">
              <span className="text-3xl p-2.5 rounded-2xl bg-blue-50 border border-blue-100 shadow-2xs">👤</span>
              <div>
                <h3 className="text-base font-bold text-slate-900">Przestrzeń osobista (Prywatna)</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Twoje prywatne notatki, zadania i bazy danych. Nikt poza Tobą nie ma do nich dostępu.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Dostępne pokoje pracy i zespoły ({workspaces.filter((w) => w.id !== 'ws-personal').length})
              </h4>

              {workspaces.filter((w) => w.id !== 'ws-personal').length === 0 ? (
                <div className="p-8 text-center bg-slate-50/70 border border-dashed border-slate-200 rounded-2xl space-y-2">
                  <Building2 size={28} className="mx-auto text-slate-300" />
                  <p className="text-xs text-slate-500">Nie masz jeszcze żadnego pokoju zespołu.</p>
                  <button
                    onClick={() => setIsCreatingTeam(true)}
                    className="px-4 py-1.5 bg-blue-600 text-white hover:bg-blue-500 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    + Utwórz pierwszy zespół
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {workspaces.map((ws) => {
                    const isCurrent = currentWorkspace?.id === ws.id;
                    const memberCount = ws.members?.length || 1;

                    return (
                      <div
                        key={ws.id}
                        onClick={() => switchWorkspace(ws.id)}
                        className={`p-5 rounded-3xl border transition-all cursor-pointer flex flex-col justify-between group ${
                          isCurrent
                            ? 'bg-blue-50/50 border-blue-400 ring-2 ring-blue-400/20'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-sm'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-2xl p-2 rounded-2xl bg-slate-50 border border-slate-100">
                              {ws.icon || (ws.id === 'ws-personal' ? '👤' : '🏢')}
                            </span>
                            {isCurrent && (
                              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold">
                                AKTYWNA
                              </span>
                            )}
                          </div>

                          <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                            {ws.name}
                          </h4>
                          <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                            {ws.description || 'Przestrzeń zespołu'}
                          </p>
                        </div>

                        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                          <span>{ws.id === 'ws-personal' ? 'Tylko Ty' : `${memberCount} współprac.`}</span>
                          <span className="text-blue-600 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                            <span>Przełącz</span>
                            <ArrowRight size={11} />
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. MODALS (Create Team, Settings, RBAC Matrix, New Announcement)          */}
      {/* ========================================================================= */}

      {/* 1. Create Team Modal */}
      {isCreatingTeam && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateTeam}
            className="p-6 bg-white border border-slate-200 rounded-3xl space-y-4 shadow-2xl max-w-md w-full animate-in fade-in zoom-in-95"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Building2 size={18} className="text-blue-600" />
                <span>Nowy pokój pracy / Zespół</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsCreatingTeam(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold block mb-1.5">Ikona pokoju:</label>
              <div className="flex flex-wrap gap-2">
                {TEAM_ICONS.map((icon) => (
                  <button
                    key={icon}
                    type="button"
                    onClick={() => setNewTeamIcon(icon)}
                    className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center cursor-pointer transition-all border ${
                      newTeamIcon === icon
                        ? 'bg-blue-50 border-blue-500 ring-2 ring-blue-500/20 scale-105'
                        : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {icon}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold block mb-1">Nazwa zespołu / firmy:</label>
              <input
                type="text"
                required
                value={newTeamName}
                onChange={(e) => setNewTeamName(e.target.value)}
                placeholder="np. Agencja Kreatywna, Studio Dev, Finanse..."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500 font-medium"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold block mb-1">
                Krótki opis lub cel pokoju (opcjonalnie):
              </label>
              <textarea
                rows={2}
                value={newTeamDesc}
                onChange={(e) => setNewTeamDesc(e.target.value)}
                placeholder="np. Przestrzeń do codziennej pracy, projektów i sprintów..."
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsCreatingTeam(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Anuluj
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-sm"
              >
                Utwórz pokój
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 2. New Announcement Modal */}
      {showNewAnnModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handlePublishAnnouncement}
            className="p-6 bg-white border border-slate-200 rounded-3xl space-y-4 shadow-2xl max-w-md w-full animate-in fade-in zoom-in-95"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Megaphone size={18} className="text-blue-600" />
                <span>Nowe ogłoszenie dla zespołu</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowNewAnnModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold block mb-1">Tytuł ogłoszenia:</label>
              <input
                type="text"
                required
                value={newAnnTitle}
                onChange={(e) => setNewAnnTitle(e.target.value)}
                placeholder="np. Demo w piątek o 14:00, Nowe wytyczne..."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500 font-medium"
              />
            </div>

            <div className="flex items-center gap-2">
              <div className="flex-1">
                <label className="text-[11px] text-slate-500 font-semibold block mb-1">Kategoria:</label>
                <select
                  value={newAnnCategory}
                  onChange={(e) => setNewAnnCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-medium focus:outline-none"
                >
                  <option value="Ważne">Ważne</option>
                  <option value="Sprint">Sprint</option>
                  <option value="Spotkanie">Spotkanie</option>
                  <option value="Informacja">Informacja</option>
                </select>
              </div>

              <div className="pt-5">
                <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newAnnPinned}
                    onChange={(e) => setNewAnnPinned(e.target.checked)}
                    className="w-4 h-4 rounded accent-blue-600"
                  />
                  <span>Przypnij na górze</span>
                </label>
              </div>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold block mb-1">Treść ogłoszenia:</label>
              <textarea
                rows={4}
                required
                value={newAnnContent}
                onChange={(e) => setNewAnnContent(e.target.value)}
                placeholder="Wpisz szczegóły ogłoszenia dla zespołu..."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500 resize-none leading-relaxed"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowNewAnnModal(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Anuluj
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-sm"
              >
                Opublikuj
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 3. Edit Team Settings Modal */}
      {editingWorkspaceId && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveSettings}
            className="p-6 bg-white border border-slate-200 rounded-3xl space-y-4 shadow-2xl max-w-md w-full animate-in fade-in zoom-in-95"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Settings size={18} className="text-blue-600" />
                <span>Ustawienia pokoju pracy</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingWorkspaceId(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold block mb-1.5">Ikona pokoju:</label>
              <div className="flex flex-wrap gap-2">
                {TEAM_ICONS.map((icon) => (
                  <button
                    key={icon}
                    type="button"
                    onClick={() => setEditIcon(icon)}
                    className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center cursor-pointer transition-all border ${
                      editIcon === icon
                        ? 'bg-blue-50 border-blue-500 ring-2 ring-blue-500/20 scale-105'
                        : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {icon}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold block mb-1">Nazwa zespołu:</label>
              <input
                type="text"
                required
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500 font-medium"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold block mb-1">Opis pokoju:</label>
              <textarea
                rows={2}
                value={editDesc}
                onChange={(e) => setEditDesc(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditingWorkspaceId(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Anuluj
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-sm"
              >
                Zapisz zmiany
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 4. RBAC Permission Matrix Modal */}
      {showRbacModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 lg:p-8 max-w-2xl w-full space-y-5 shadow-2xl max-h-[85vh] overflow-y-auto animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Shield size={20} className="text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Matryca Uprawnień RBAC w pokojach pracy</h3>
              </div>
              <button
                onClick={() => setShowRbacModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-200 text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Uprawnienie / Funkcja</th>
                    <th className="px-3 py-3 text-center text-purple-700 font-bold">Owner</th>
                    <th className="px-3 py-3 text-center text-blue-700 font-bold">Admin</th>
                    <th className="px-3 py-3 text-center text-emerald-700 font-bold">Editor</th>
                    <th className="px-3 py-3 text-center text-slate-600 font-bold">Viewer</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  <tr>
                    <td className="px-4 py-2.5 font-medium">Usuwanie całego zespołu</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 font-medium">Ustawienia pokoju (nazwa, ikona, opis)</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 font-medium">Zapraszanie nowych współpracowników</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 font-medium">Zmiana ról i usuwanie członków</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 font-medium">Tworzenie i edycja dokumentów & zadań</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-slate-300">—</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 font-medium">Podgląd, odczyt oraz komentowanie</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                    <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">✓</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {Object.entries(ROLE_CONFIG).map(([key, cfg]) => (
                <div key={key} className={`p-3 rounded-2xl border ${cfg.bg} ${cfg.border}`}>
                  <div className={`font-bold ${cfg.color}`}>{cfg.label}</div>
                  <div className="text-[11px] text-slate-600 mt-0.5">{cfg.desc}</div>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowRbacModal(false)}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-sm"
              >
                Zamknij przewodnik
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. Delete Member Confirmation Modal */}
      {memberToRemove && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <AlertCircle size={16} className="text-rose-600" />
              <span>Czy na pewno usunąć członka?</span>
            </h3>
            <p className="text-xs text-slate-600">
              Użytkownik <strong>{memberToRemove.name}</strong> utraci natychmiast dostęp do tego pokoju pracy.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setMemberToRemove(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Anuluj
              </button>
              <button
                onClick={async () => {
                  await removeTeamMember(currentWorkspace.id, memberToRemove.userId);
                  setMemberToRemove(null);
                  showStatus('Usunięto członka z zespołu.');
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-2xs"
              >
                Usuń
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Delete Workspace Confirmation Modal */}
      {teamToDelete && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <AlertCircle size={16} className="text-rose-600" />
              <span>Usunięcie całego pokoju pracy</span>
            </h3>
            <p className="text-xs text-slate-600">
              Czy na pewno chcesz bezpowrotnie usunąć zespół <strong>{teamToDelete.name}</strong>? Ta operacja jest
              nieodwracalna.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setTeamToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Anuluj
              </button>
              <button
                onClick={async () => {
                  await deleteTeamWorkspace(teamToDelete.id);
                  setTeamToDelete(null);
                  showStatus('Pomyślnie usunięto zespół.', 'info');
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-2xs"
              >
                Usuń zespół
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
