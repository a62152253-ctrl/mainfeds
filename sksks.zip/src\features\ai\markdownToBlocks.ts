import { DocBlock, BlockType } from '../../types/workspace';

/**
 * Intelligent Markdown to Notion-Style Blocks Parser
 * Converts raw markdown/AI responses into 52 rich Notion blocks:
 * - h1, h2, h3, h4
 * - key_takeaway, pros_cons, callout_tip, callout_info, callout_warning, callout_danger
 * - code, terminal, sql, json, diff
 * - table, stat_grid, todo, bullet, number, divider
 * - ai_prompt, signature
 */
export function parseMarkdownToNotionBlocks(
  rawText: string,
  customTitle?: string
): { title: string; blocks: DocBlock[] } {
  if (!rawText || !rawText.trim()) {
    return {
      title: customTitle || 'Nowa Notatka',
      blocks: [
        {
          id: `block-${Date.now()}-0`,
          type: 'p',
          content: '',
        },
      ],
    };
  }

  const lines = rawText.split('\n');
  let extractedTitle = customTitle;
  const blocks: DocBlock[] = [];
  let blockCounter = 0;

  const nextId = (prefix = 'ai-blk') =>
    `${prefix}-${Date.now()}-${blockCounter++}-${Math.random().toString(36).slice(2, 6)}`;

  // 1. Extract title if not customTitle
  let startLineIndex = 0;
  if (!extractedTitle) {
    for (let i = 0; i < Math.min(lines.length, 5); i++) {
      const line = lines[i].trim();
      if (line.startsWith('# ')) {
        extractedTitle = line.replace(/^#\s+/, '').replace(/[*_`]/g, '').trim();
        startLineIndex = i + 1;
        break;
      }
    }
  }

  if (!extractedTitle) {
    for (let i = 0; i < Math.min(lines.length, 5); i++) {
      const line = lines[i].trim();
      if (line.length > 0 && !line.startsWith('```') && !line.startsWith('>')) {
        extractedTitle = line.replace(/[*_`#]/g, '').slice(0, 60).trim();
        break;
      }
    }
  }

  extractedTitle = extractedTitle || 'Notatka od AI';

  // 2. Iterate through lines and build structured blocks
  let i = startLineIndex;
  while (i < lines.length) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();

    // Skip empty lines
    if (!trimmed) {
      i++;
      continue;
    }

    // Code block detection ```
    if (trimmed.startsWith('```')) {
      const langMatch = trimmed.match(/^```([a-zA-Z0-9_\-+]*)/);
      const rawLang = langMatch ? langMatch[1].toLowerCase() : '';
      const codeLines: string[] = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith('```')) {
        codeLines.push(lines[i]);
        i++;
      }
      if (i < lines.length && lines[i].trim().startsWith('```')) {
        i++; // skip closing ```
      }

      const codeContent = codeLines.join('\n');
      let blockType: BlockType = 'code';
      let lang = rawLang || 'typescript';

      if (['bash', 'sh', 'shell', 'zsh', 'terminal', 'cmd'].includes(rawLang)) {
        blockType = 'terminal';
        lang = 'bash';
      } else if (rawLang === 'sql') {
        blockType = 'sql';
        lang = 'sql';
      } else if (rawLang === 'json') {
        blockType = 'json';
        lang = 'json';
      } else if (rawLang === 'diff') {
        blockType = 'diff';
        lang = 'diff';
      } else if (rawLang === 'mermaid') {
        blockType = 'mermaid';
        lang = 'mermaid';
      }

      blocks.push({
        id: nextId('code'),
        type: blockType,
        content: blockType === 'mermaid' ? 'Diagram Architektury' : codeContent,
        diagramSyntax: blockType === 'mermaid' ? codeContent : undefined,
        language: lang,
      });
      continue;
    }

    // Markdown Table detection (| header | header |)
    if (trimmed.startsWith('|') && trimmed.endsWith('|') && trimmed.includes('|')) {
      const tableRows: string[][] = [];
      while (i < lines.length && lines[i].trim().startsWith('|') && lines[i].trim().endsWith('|')) {
        const rowLine = lines[i].trim();
        // check if separator row like |---|---|
        if (!/^[|\s-:]+$/.test(rowLine)) {
          const cells = rowLine
            .split('|')
            .slice(1, -1)
            .map((c) => c.trim());
          tableRows.push(cells);
        }
        i++;
      }

      if (tableRows.length > 0) {
        blocks.push({
          id: nextId('tbl'),
          type: 'table',
          content: 'Tabela zestawienia',
          tableData: tableRows,
        });
      }
      continue;
    }

    // Dividers
    if (/^(---|___|\*\*\*)$/.test(trimmed)) {
      blocks.push({
        id: nextId('div'),
        type: 'divider',
        content: '',
      });
      i++;
      continue;
    }

    // Headings
    if (trimmed.startsWith('# ')) {
      blocks.push({
        id: nextId('h1'),
        type: 'h1',
        content: trimmed.replace(/^#\s+/, ''),
      });
      i++;
      continue;
    }
    if (trimmed.startsWith('## ')) {
      blocks.push({
        id: nextId('h2'),
        type: 'h2',
        content: trimmed.replace(/^##\s+/, ''),
      });
      i++;
      continue;
    }
    if (trimmed.startsWith('### ')) {
      // Check if this heading indicates a Key Takeaways section
      const headingText = trimmed.replace(/^###\s+/, '');
      if (/wnioski|takeaways|podsumowanie|kluczowe/i.test(headingText)) {
        // Collect following bullet points as key takeaway content
        const takeawayLines: string[] = [];
        i++;
        while (i < lines.length && (lines[i].trim().startsWith('-') || lines[i].trim().startsWith('*') || lines[i].trim().startsWith('•'))) {
          takeawayLines.push(lines[i].trim().replace(/^[-*•]\s*/, ''));
          i++;
        }
        blocks.push({
          id: nextId('callout'),
          type: 'callout',
          calloutType: 'info',
          content: takeawayLines.length > 0 
            ? `💡 ${headingText}:\n` + takeawayLines.map((t) => `• ${t}`).join('\n')
            : `💡 ${headingText}`,
        });
        continue;
      }

      // Check if Pros and Cons section
      if (/zalety|wady|plusy|minusy|pros|cons/i.test(headingText)) {
        let prosText = '';
        let consText = '';
        let currentMode: 'pros' | 'cons' = 'pros';
        i++;
        while (i < lines.length && !lines[i].trim().startsWith('#')) {
          const checkLine = lines[i].trim();
          if (/zalety|plusy|pros/i.test(checkLine)) {
            currentMode = 'pros';
          } else if (/wady|minusy|cons/i.test(checkLine)) {
            currentMode = 'cons';
          } else if (checkLine.startsWith('-') || checkLine.startsWith('+') || checkLine.startsWith('*')) {
            const clean = checkLine.replace(/^[-+*]\s*/, '');
            if (currentMode === 'pros') {
              prosText += (prosText ? '\n' : '') + `+ ${clean}`;
            } else {
              consText += (consText ? '\n' : '') + `- ${clean}`;
            }
          }
          i++;
        }
        blocks.push({
          id: nextId('proscons'),
          type: 'pros_cons',
          content: prosText || '+ Kluczowe zalety i mocne strony rozwiązania',
          toggleDetails: consText || '- Kwestie wymagające uwagi lub ograniczenia',
        });
        continue;
      }

      blocks.push({
        id: nextId('h3'),
        type: 'h3',
        content: headingText,
      });
      i++;
      continue;
    }
    if (trimmed.startsWith('#### ')) {
      blocks.push({
        id: nextId('h4'),
        type: 'h4',
        content: trimmed.replace(/^####\s+/, ''),
      });
      i++;
      continue;
    }

    // Callout / Blockquotes (> or > [!NOTE])
    if (trimmed.startsWith('>')) {
      const quoteLines: string[] = [];
      let calloutType: 'info' | 'tip' | 'warning' | 'danger' = 'info';
      let bType: BlockType = 'callout_info';

      while (i < lines.length && lines[i].trim().startsWith('>')) {
        let qLine = lines[i].trim().replace(/^>\s?/, '');
        if (/\[!NOTE\]|\[!INFO\]/i.test(qLine)) {
          bType = 'callout_info';
          calloutType = 'info';
          qLine = qLine.replace(/\[!(NOTE|INFO)\]/i, '').trim();
        } else if (/\[!TIP\]/i.test(qLine)) {
          bType = 'callout_tip';
          calloutType = 'tip';
          qLine = qLine.replace(/\[!TIP\]/i, '').trim();
        } else if (/\[!WARNING\]/i.test(qLine)) {
          bType = 'callout_warning';
          calloutType = 'warning';
          qLine = qLine.replace(/\[!WARNING\]/i, '').trim();
        } else if (/\[!DANGER\]|\[!CAUTION\]/i.test(qLine)) {
          bType = 'callout_danger';
          calloutType = 'danger';
          qLine = qLine.replace(/\[!(DANGER|CAUTION)\]/i, '').trim();
        } else if (/🏆|Kluczowy wniosek|Kluczowy cel|Sukces/i.test(qLine)) {
          bType = 'key_takeaway';
        }
        if (qLine) quoteLines.push(qLine);
        i++;
      }

      blocks.push({
        id: nextId('callout'),
        type: bType,
        content: quoteLines.join('\n'),
        calloutType,
      });
      continue;
    }

    // Todo / Checkbox (- [ ] or - [x])
    if (/^[-*]\s+\[([ xX])\]\s+/.test(trimmed)) {
      const isChecked = /^[-*]\s+\[[xX]\]/.test(trimmed);
      const text = trimmed.replace(/^[-*]\s+\[([ xX])\]\s+/, '');
      blocks.push({
        id: nextId('todo'),
        type: 'todo',
        content: text,
        checked: isChecked,
      });
      i++;
      continue;
    }

    // Bullet List (- or * or •)
    if (/^[-*•]\s+/.test(trimmed)) {
      blocks.push({
        id: nextId('bullet'),
        type: 'bullet',
        content: trimmed.replace(/^[-*•]\s+/, ''),
      });
      i++;
      continue;
    }

    // Numbered List (1. 2. 3.)
    if (/^\d+\.\s+/.test(trimmed)) {
      blocks.push({
        id: nextId('num'),
        type: 'number',
        content: trimmed.replace(/^\d+\.\s+/, ''),
      });
      i++;
      continue;
    }

    // Inlined callout tips (💡, ⚠️, ℹ️, 🚨)
    if (trimmed.startsWith('💡') || trimmed.toLowerCase().startsWith('wskazówka:')) {
      blocks.push({
        id: nextId('tip'),
        type: 'callout_tip',
        content: trimmed,
        calloutType: 'tip',
      });
      i++;
      continue;
    }
    if (trimmed.startsWith('⚠️') || trimmed.toLowerCase().startsWith('uwaga:')) {
      blocks.push({
        id: nextId('warn'),
        type: 'callout_warning',
        content: trimmed,
        calloutType: 'warning',
      });
      i++;
      continue;
    }

    // Regular paragraph
    blocks.push({
      id: nextId('p'),
      type: 'p',
      content: trimmed,
    });
    i++;
  }

  // Ensure there is at least one content block
  if (blocks.length === 0) {
    blocks.push({
      id: nextId('p'),
      type: 'p',
      content: rawText,
    });
  }

  // Append Interactive AI Prompt Block
  blocks.push({
    id: nextId('ai-prompt'),
    type: 'ai_prompt',
    content: `Zadaj pytanie lub poproś AI o rozwinięcie wybranej sekcji tego dokumentu...`,
  });

  // Append Signature Block
  blocks.push({
    id: nextId('sig'),
    type: 'signature',
    content: 'SearchPoint AI Knowledge Engine',
    timelineDate: new Date().toLocaleDateString('pl-PL'),
  });

  return {
    title: extractedTitle,
    blocks,
  };
}
